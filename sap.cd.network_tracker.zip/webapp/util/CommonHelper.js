(function() {
	"use strict";

	sap.ui.define([], function() {
		return {
			/**
			 * 
			 */
			attachEnterToField: function(oControl, fnFunction, oListener) {
				var oEventDelegate;
				oEventDelegate = {
					onsapenter: fnFunction
				};
				oControl.data("oEventDelegate", oEventDelegate);
				oControl.addEventDelegate(oEventDelegate, oListener);
			},

			/**
			 * 
			 */
			detachEnterFromField: function(oControl) {
				var oEventDelegate;
				oEventDelegate = oControl.data("oEventDelegate");
				if (oEventDelegate !== null) {
					oControl.removeEventDelegate(oEventDelegate);
				}
			},

			createControlForODataType: function(sType, sValuePath, oProperties, aCustomData, sValueStatePath, fnValueEventHandler) {
				var oControl = null;
				/*
				 * var oProperties = { MaxLength: iLength, Precision: iPrecision, Scale: iScale };
				 */
				switch (sType) {
					case "Edm.Int":
					case "Edm.Byte":
					case "Edm.SByte":
					case "Edm.Int16":
					case "Edm.Int32":
					case "Edm.Int64":
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Time":
						oControl = new sap.m.Input({
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.Time"
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.DateTime":
						oControl = new sap.m.DatePicker({
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.DateTime",
								formatOptions: {
									pattern: 'yyyy-MM-dd\'T\'HH:mm:ss',
									UTC: true
								}
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Boolean":
						oControl = new sap.m.Select({
							customData: aCustomData,
							selectedKey: {
								path: sValuePath,
								type: "sap.ui.model.type.Boolean"
							},
							items: [
								new sap.ui.core.Item({
									text: "",
									key: ""
								}), new sap.ui.core.Item({
									text: "True",
									key: "true"
								}), new sap.ui.core.Item({
									text: "False",
									key: "false"
								})
							]
						});
						break;
					case "Edm.Decimal":
						// TODO: have type with float and constraints
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties.Precision ? oProperties.Precision : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Double":
					case "Edm.Single":
						// TODO : have type with float and constraints
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.String":
					case "Edm.Guid":
					default:
						oControl = new sap.m.Input({
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.String"
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;
				}

				if (typeof fnValueEventHandler === "function") {
					if (oControl instanceof sap.m.Input || oControl instanceof sap.m.DatePicker || oControl instanceof sap.m.Select) {
						oControl.attachChange($.proxy(fnValueEventHandler, this));
					}
				}

				return oControl;
			}
		};
	});
})();