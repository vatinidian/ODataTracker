(function() {
	"use strict";
	sap.ui.define([
		"sap/ui/model/odata/v2/ODataModel", "sap/ui/model/json/JSONModel", "sap/ui/core/format/DateFormat"
	], function(ODataModel, JSONModel, DateFormat) {
		sap.ui.base.Object.extend("sap.cd.ODataTracker.util.ModelHelper", {
			// reference to component
			_oComponent: null,
			aDataTypes: [
				"Edm.String", "Edm.Int", "Edm.Int16", "Edm.Int32", "Edm.Int64", "Edm.Binary", "Edm.Boolean", "Edm.Byte", "Edm.SByte",
				"Edm.DateTime", "Edm.Decimal", "Edm.Double", "Edm.Single", "Edm.Guid", "Edm.Time", null
			],
			constructor: function(oComponent) {
				this._oComponent = oComponent;

				// Create Query Model
				var oQuery = {
					"Queries": []
				};
				var oQueryModel = new JSONModel(oQuery);
				this._oComponent.setModel(oQueryModel, "QueryModel");
			},
			/**
			 * 
			 */
			registerForModelLoadedFromFile: function(fnHandler, oListener) {
				var oMainModel = this._oComponent.getModel();
				var oBinding = new sap.ui.model.json.JSONPropertyBinding(oMainModel, "/ModelLoadedFromFile");
				oBinding.attachChange(function(oEvent) {
					var bModelLoadedFromFile = oMainModel.getProperty("/ModelLoadedFromFile");
					// call the handler on the listener
					fnHandler.apply(oListener, [
						bModelLoadedFromFile
					]);
				}, this);

				var bModelLoadedFromFileCurrentValue = oMainModel.getProperty("/ModelLoadedFromFile");
				fnHandler.apply(oListener, [
					bModelLoadedFromFileCurrentValue
				]);
			},

			/**
			 * 
			 */
			registerForModelChange: function(fnHandler, oListener) {
				// TODO : Test
				var oMainModel = this._oComponent.getModel();
				var oBinding = new sap.ui.model.json.JSONPropertyBinding(oMainModel, "/ModelChanged");
				oBinding.attachChange(function(oEvent) {
					var bModelChanged = oMainModel.getProperty("/ModelChanged");
					// call the handler on the listener
					fnHandler.apply(oListener, [
						bModelChanged
					]);
				}, this);

				var bModelChangedCurrentValue = oMainModel.getProperty("/ModelChanged");
				fnHandler.apply(oListener, [
					bModelChangedCurrentValue
				]);
			},

			/**
			 * 
			 */
			registerForSchemaChange: function(fnHandler, oListener) {
				// TODO : Test
				var oMainModel = this._oComponent.getModel();
				var oBinding = new sap.ui.model.json.JSONPropertyBinding(oMainModel, "/schema");
				oBinding.attachChange(function(oEvent) {
					var bModelChanged = true;
					// call the handler on the listener
					fnHandler.apply(oListener, [
						bModelChanged
					]);
				}, this);
			},

			_createModel: function(sURL, mParameters) {
				var oDataModel = new ODataModel(sURL);
				var oModel = this._oComponent.getModel();

				oModel.setProperty("/bServiceURLUsed", true);
				oModel.setProperty("/ConfigurationFileUsed", false);
				oModel.setProperty("/ModelLoadedFromFile", false);

				// TODO : Optimize
				this._oComponent.setModel(oDataModel, "oDataModel");

				oDataModel.attachMetadataLoaded(function(oSuccess) {
					if (mParameters && typeof mParameters.success === "function") {
						var oMetadata = oSuccess.getParameter("metadata");
						mParameters.success(oMetadata);
					}
				}, this);

				oDataModel.attachMetadataFailed(function(oError) {
					oModel.setProperty("/ModelChanged", false);

					if (mParameters && typeof mParameters.error === "function") {
						mParameters.error(oError);
					}
				}, this);
			},

			/**
			 * 
			 */
			compareMainModel: function(sURL) {
				// Get new Schema object
				// var aNewSchemas = [];
				var oHelper = this;
				this._createModel(sURL, {
					success: function(oDataModel) {
						var oNewModel = new JSONModel();
						oHelper._oComponent.setModel(oNewModel, "MetadataUpdate");
						// TODO : Check
						var oServiceMetadata = oDataModel.getServiceMetadata();
						var oDataServices = oServiceMetadata.dataServices;

						if (!$.isEmptyObject(oDataServices)) {
							// aNewSchemas = (oDataServices.schema).slice();
							oHelper._oComponent.getModel("MetadataUpdate").setProperty("/schema", oDataServices.schema);
							oHelper.enhanceModelToAddCRUDObject("MetadataUpdate");
							oHelper.enhanceModelAddEntityTypeToEntitySetObject("MetadataUpdate");
							// Compare Old Schema with new one and Update the model with status and Check flag properties
							oHelper._compareAndUpdateSchema();
						}
					},

					error: function(oError) {
						// TODO : Handle
					}
				});
			},

			_compareAndUpdateSchema: function() {
				var oMainModel = this._oComponent.getModel();
				var aOldSchemas = oMainModel.getProperty("/schema");

				var oUpdatedMainModel = this._oComponent.getModel("MetadataUpdate");
				var aNewSchemas = oUpdatedMainModel.getProperty("/schema");

				for (var iNewSchemaItr = 0; iNewSchemaItr < aNewSchemas.length; iNewSchemaItr++) {
					aNewSchemas[iNewSchemaItr].Status = "New";
					for (var iOldSchemaItr = 0; iOldSchemaItr < aOldSchemas.length; iOldSchemaItr++) {
						// Check for "namespace"
						if (aNewSchemas[iNewSchemaItr].namespace === aOldSchemas[iOldSchemaItr].namespace && !aOldSchemas[iOldSchemaItr].Checked) {
							// Add and Update property
							aOldSchemas[iOldSchemaItr].Checked = true;
							aOldSchemas[iOldSchemaItr].Status = "NoChange";

							aNewSchemas[iNewSchemaItr].Status = "NoChange";

							// call CompareEntityContainer function
							this._compareEntityContainer(aOldSchemas[iOldSchemaItr], aNewSchemas[iNewSchemaItr], iOldSchemaItr);
							break;
						} else if (aNewSchemas[iNewSchemaItr].namespace !== aOldSchemas[iOldSchemaItr].namespace && !aOldSchemas[iOldSchemaItr].Checked) {
							// Add and Update property
							aOldSchemas[iOldSchemaItr].Status = "Deleted";
						}
					}
				}

				// Check the status and add it to old Schema
				var aOldSchemasCpy = aOldSchemas.slice();
				for (var i = 0; i < aNewSchemas.length; i++) {
					if (aNewSchemas[i].Status === "New") {
						aOldSchemasCpy.push(aNewSchemas[i]);
					}
				}

				for (var j = 0; j < aOldSchemas.length; j++) {
					if (!aOldSchemas[j].Status) {
						aOldSchemas[j].Status = "Deleted";
					}
				}

				// TODO : Update the model
				oMainModel.setProperty("/schema", aNewSchemas);
			},

			_compareEntityContainer: function(oOldSchema, oNewSchema, iIndex) {
				// Compare entityContainers and update the model
				var aOldEntityContainers = oOldSchema.entityContainer ? oOldSchema.entityContainer : [];
				var aNewEntityContainers = oNewSchema.entityContainer ? oNewSchema.entityContainer : [];

				for (var iNewEntityCntItr = 0; iNewEntityCntItr < aNewEntityContainers.length; iNewEntityCntItr++) {
					aNewEntityContainers[iNewEntityCntItr].Status = "New";
					for (var iOldEntityCntItr = 0; iOldEntityCntItr < aOldEntityContainers.length; iOldEntityCntItr++) {
						// Check for "namespace"
						if (aNewEntityContainers[iNewEntityCntItr].name === aOldEntityContainers[iOldEntityCntItr].name && !aOldEntityContainers[
								iOldEntityCntItr].Checked) {
							// Add and Update property
							aOldEntityContainers[iOldEntityCntItr].Checked = true;
							aOldEntityContainers[iOldEntityCntItr].Status = "NoChange";

							aNewEntityContainers[iNewEntityCntItr].Status = "NoChange";

							var sPath = "/schema/" + iIndex + "/entityContainer/" + iOldEntityCntItr;
							// call CompareEntityContainer function
							this._compareEntitySet(aOldEntityContainers[iOldEntityCntItr], aNewEntityContainers[iNewEntityCntItr], sPath);
							break;
						} else if (aNewEntityContainers[iNewEntityCntItr].name !== aOldEntityContainers[iOldEntityCntItr].name && !aOldEntityContainers[
								iOldEntityCntItr].Checked) {
							// Add and Update property
							aOldEntityContainers[iOldEntityCntItr].Status = "Deleted";
						}
					}
				}

				var oMainModel = this._oComponent.getModel();
				// Check the status and add it to old Schema
				var aOldEntityCntCpy = aOldEntityContainers.slice();
				for (var i = 0; i < aNewEntityContainers.length; i++) {
					if (aNewEntityContainers[i].Status === "New") {
						oMainModel.setProperty("/schema/" + iIndex + "/Status", "Change");
						aOldEntityCntCpy.push(aNewEntityContainers[i]);
					}
				}

				for (var j = 0; j < aOldEntityContainers.length; j++) {
					if (!aOldEntityContainers[j].Status || aOldEntityContainers[j].Status === "Deleted") {
						aOldEntityContainers[j].Status = "Deleted";
						oMainModel.setProperty("/schema/" + iIndex + "/Status", "Change");
					}
				}
				oMainModel.setProperty("/schema/" + iIndex + "/entityContainer", aOldEntityCntCpy);
			},

			/**
			 * 
			 */
			enhanceModelAddEntityTypeToEntitySetObject: function(sModelName) {
				var oModel;
				if (!sModelName) {
					oModel = this._oComponent.getModel();
				} else {
					oModel = this._oComponent.getModel(sModelName);
				}

				var aSchema = oModel.getProperty("/schema");
				var mSchemaEntityTypes = {};
				var aSchemas = [];
				var mSchemaComplexTypes = {};
				var mComplexyTypes = {};

				// Create Map with SchemaName and EntityTypes array as Value
				for (var i = 0; i < aSchema.length; i++) {
					var aEntitiesInSchema = aSchema[i].entityType;
					if (aEntitiesInSchema && aEntitiesInSchema.length > 0) {
						mSchemaEntityTypes[aSchema[i].namespace] = aEntitiesInSchema;
					}

					var aComplexTypesInSchema = aSchema[i].complexType ? aSchema[i].complexType : [];
					if (aComplexTypesInSchema && aComplexTypesInSchema.length > 0) {
						mSchemaComplexTypes[aSchema[i].namespace] = aComplexTypesInSchema;
					}

					for (var iComplexProp = 0; iComplexProp < aComplexTypesInSchema.length; iComplexProp++) {
						var aComplexProperties = aComplexTypesInSchema[iComplexProp].property;
						var oComplexProperty = {};

						for (var iComplex = 0; iComplex < aComplexProperties.length; iComplex++) {
							aComplexProperties[iComplex].name = aComplexTypesInSchema[iComplexProp].name + "/" + aComplexProperties[iComplex].name;
							aComplexProperties[iComplex].key = false;
							aComplexProperties[iComplex].complexParent = true;
							aComplexProperties[iComplex].complexType = false;
							aComplexProperties[iComplex].value = null;
							aComplexProperties[iComplex].ValueState = "None";
						}
						mComplexyTypes[aComplexTypesInSchema[iComplexProp].name] = aComplexProperties;
					}

					aSchemas.push(aSchema[i].namespace);
				}

				for (var i = 0; i < aSchema.length; i++) {
					// Get the ComplexTypes
					var aComplexTypes = oModel.getProperty("/schema/" + i + "/complexType/");

					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {
						var aFunctionImports = oModel.getProperty("/schema/" + i + "/entityContainer/0/functionImport") ? oModel.getProperty("/schema/" +
							i + "/entityContainer/0/functionImport") : [];
						for (var j = 0; j < aFunctionImports.length; j++) {
							aFunctionImports[j].RequestData = [];
							aFunctionImports[j].Valid = true;
							aFunctionImports[j].DataEntered = false;
							var aParameters = oModel.getProperty("/schema/" + i + "/entityContainer/0/functionImport/" + j + "/parameter") ? oModel.getProperty(
								"/schema/" + i + "/entityContainer/0/functionImport/" + j + "/parameter") : [];
							for (var k = 0; k < aParameters.length; k++) {
								aParameters[k].value = null;
								aParameters[k].ValueState = "None";
							}

							var aFnImportReqData = oModel.getProperty("/schema/" + i + "/entityContainer/0/functionImport/" + j + "/RequestData/");
							var bModelFromFile = oModel.getProperty("ModelLoadedFromFile");
							if ((bModelFromFile && !(aFnImportReqData && aFnImportReqData.length)) || (!bModelFromFile && !(aFnImportReqData &&
									aFnImportReqData.length))) {
								for (var k = 0; k < aParameters.length; k++) {
									oModel.setProperty("/schema/" + i + "/entityContainer/0/functionImport/" + j + "/RequestData/0", $.extend(true, {},
										aFunctionImports[j]));
								}
							}
						}

						var aEntities = [];
						// TODO : Check how to handle Diff entityContainers
						var aEntitySets = oModel.getProperty("/schema/" + i + "/entityContainer/0/entitySet");
						for (var j = 0; j < aEntitySets.length; j++) {
							var sEntityType = aEntitySets[j].entityType;
							var sEntityName = "";

							for (var iSchemaCnt = 0; iSchemaCnt < aSchemas.length; iSchemaCnt++) {
								if (sEntityType.indexOf(aSchemas[iSchemaCnt]) !== -1) {
									aEntities = mSchemaEntityTypes[aSchemas[iSchemaCnt]];
									sEntityName = sEntityType.replace(aSchemas[iSchemaCnt] + ".", "");
									break;
								}
							}

							for (var iEntity = 0; iEntity < aEntities.length; iEntity++) {
								if (aEntities[iEntity]["name"] === sEntityName) {
									aEntities[iEntity].Valid = true;
									aEntities[iEntity].DataEntered = false;
									oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/entity", aEntities[iEntity]);

									// Get Entity
									var oEntity = aEntities[iEntity];

									// Get Key Property
									var aKeys = oEntity.key.propertyRef;
									var aProperties = oEntity.property;

									var mComplexTypesToConcat = {};
									for (var iProperty = 0; iProperty < aProperties.length; iProperty++) {
										aProperties[iProperty].key = false;
										aProperties[iProperty].value = null;
										aProperties[iProperty].ValueState = "None";
										aProperties[iProperty]["complexType"] = false;
										aProperties[iProperty]["complexParent"] = false;

										if (this.aDataTypes.indexOf(aProperties[iProperty].type) === -1 && aProperties[iProperty].type.indexOf("Edm") === -1) {
											aProperties[iProperty]["complexType"] = true;

											$.each(mSchemaComplexTypes, function(sComplexTypePath, aComplexTypes) {
												for (var iComType = 0; iComType < aComplexTypes.length; iComType++) {
													if (sComplexTypePath + "." + aComplexTypes[iComType].name === aProperties[iProperty].type) {
														mComplexTypesToConcat[aComplexTypes[iComType].name] = mComplexyTypes[aComplexTypes[iComType].name];
														return;
													}
												}
											});

										}
									}

									$.each(mComplexTypesToConcat, function(sComplexPath, aComplexProperties) {
										aProperties = aProperties.concat(aComplexProperties);
									});

									for (var jKey = 0; jKey < aKeys.length; jKey++) {
										for (var iProperty = 0; iProperty < aProperties.length; iProperty++) {
											if (aKeys[jKey].name === aProperties[iProperty].name) {
												aProperties[iProperty].key = true;
												break;
											}
										}
									}

									oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/entity/property/", aProperties);
									var aReqData = oModel.getProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/crud/Create/RequestData/")
									var bModelFromFile = oModel.getProperty("ModelLoadedFromFile");
									if ((bModelFromFile && !(aReqData && aReqData.length)) || (!bModelFromFile && !(aReqData && aReqData.length))) {
										oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/crud/Create/RequestData/0", $.extend(true, {},
											aEntities[iEntity]));
										oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/crud/Update/RequestData/0", $.extend(true, {},
											aEntities[iEntity]));
										oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/crud/Delete/RequestData/0", $.extend(true, {},
											aEntities[iEntity]));
									}
									break;
								}
							}
						}
					}
				}
			},

			_formFilterPath: function(oFilter) {
				var sFilterPath = "";
				if (!oFilter["Value1"]) {
					return sFilterPath;
				}

				var sValue1 = jQuery.sap.encodeURL(String(this._parseValueBasedOnType(oFilter["Value1"], oFilter["DataType"])));
				var sValue2 = jQuery.sap.encodeURL(String(this._parseValueBasedOnType(oFilter["Value2"], oFilter["DataType"])));

				var sOperator = oFilter["Operator"].toLowerCase();
				switch (sOperator) {
					case "bt":
						if (oFilter["Value2"]) {
							sFilterPath = "(" + oFilter["Property"] + "%20ge%20" + sValue1 + "%20and%20" + oFilter["Property"] + "%20le%20" + sValue2 +
								")";
						}
						break;
					case "eq":
					case "ne":
					case "gt":
					case "ge":
					case "lt":
					case "le":
						sFilterPath = oFilter["Property"] + "%20" + sOperator + "%20" + sValue1;
						break;
					case "startswith":
					case "endswith":
						sFilterPath = sOperator + "(" + oFilter["Property"] + "," + sValue1 + ")";
						break;
					case "Contains":
						sFilterPath = "substringof(" + sValue1 + "," + oFilter["Property"] + ")";
						break;
				};

				return sFilterPath;
			},

			/**
			 * TODO : Document
			 */
			createQueryModel: function(sModelName) {
				// Loop the CRUD Request data
				var oModel;
				if (!sModelName) {
					oModel = this._oComponent.getModel();
				} else {
					oModel = this._oComponent.getModel(sModelName);
				}

				var aSchema = oModel.getProperty("/schema");
				var sSchemaName = "";
				// Update the QueryModel
				var aQueries = [];
				for (var i = 0; i < aSchema.length; i++) {
					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {
						sSchemaName = aSchema[i].namespace;
						var aEntitySets = oModel.getProperty("/schema/" + i + "/entityContainer/0/entitySet");
						for (var j = 0; j < aEntitySets.length; j++) {
							// Get CRUD object
							var oCRUD = aEntitySets[j].crud;
							var sPath = "/schema/" + i + "/entityContainer/0/entitySet/" + j;

							// Read Queries
							if (oCRUD["Read"].Available) {
								var aReadQueries = this._createReadQueries(sPath, sSchemaName);
								if (aReadQueries && aReadQueries.length > 0) {
									aQueries = aQueries.concat(aReadQueries);
								}
							}

							// Update Queries
							if (oCRUD["Update"].Available) {
								var aUpdateQueries = this._createUpdateQueries(sPath, sSchemaName);
								if (aUpdateQueries && aUpdateQueries.length > 0) {
									aQueries = aQueries.concat(aUpdateQueries);
								}
							}

							// Create Queries
							if (oCRUD["Create"].Available) {
								var aCreateQueries = this._createCreateQueries(sPath, sSchemaName);
								if (aCreateQueries && aCreateQueries.length > 0) {
									aQueries = aQueries.concat(aCreateQueries);
								}
							}

							// Delete Queries
							if (oCRUD["Delete"].Available) {
								var aDeleteQueries = this._createDeleteQueries(sPath, sSchemaName);
								if (aDeleteQueries && aDeleteQueries.length > 0) {
									aQueries = aQueries.concat(aDeleteQueries);
								}
							}
						}
					}
				}

				var oQueryModel = this._oComponent.getModel("QueryModel");
				oQueryModel.setProperty("/Queries", aQueries);
			},

			_getQuerySampleObject: function() {

				var oModel = this._oComponent.getModel();
				var sServiceUrl = oModel.getProperty("/ServiceUrl");

				return {
					Path: sServiceUrl,
					HTTPMethod: "",
					CRUDType: "",
					Data: [],
					CRUDModelPath: "",
					RequestData: {
						Data: {},
						Headers: {},
						Accepts: {},
						crossDomain: "",
						dataType: "",
						DataArray: []
					},
					SampleDataPath: "",
					Headers: {
						URL: "",
						Method: "",
						Async: true
					},
					Response: {
						Time: "",
						ContentType: "",
						Data: {},
						RawHeaders: "",
						Headers: []
					},
					Status: "",
					StatusIndicator: false,
					SAPStatistics: {},
					Source: {
						Schema: "",
						EntitySet: ""
					}
				};
			},

			_parseValueBasedOnType: function(vValue, sType, bKey) {
				/*
				 * Copied from OData-based DataBinding utility Class
				 */

				// Lazy creation of format objects
				if (!this.oDateTimeFormat) {
					this.oDateTimeFormat = DateFormat.getDateInstance({
						pattern: "'datetime'''yyyy-MM-dd'T'HH:mm:ss''"
					});
					this.oDateTimeOffsetFormat = DateFormat.getDateInstance({
						pattern: "'datetimeoffset'''yyyy-MM-dd'T'HH:mm:ss'Z'''"
					});
					this.oTimeFormat = DateFormat.getTimeInstance({
						pattern: "'time''PT'HH'H'mm'M'ss'S'''"
					});
				}

				// null values should return the null literal
				if (vValue === null || vValue === undefined) {
					return "null";
				}

				// Format according to the given type
				var sValue;
				switch (sType) {
					case "Edm.String":
						// quote
						sValue = "'" + String(vValue).replace(/'/g, "''") + "'";
						break;
					case "Edm.Time":
						if (typeof vValue === "object") {
							sValue = this.oTimeFormat.format(new Date(vValue.ms), true);
						} else {
							sValue = "time'" + vValue + "'";
						}
						break;
					case "Edm.DateTime":
						sValue = this.oDateTimeFormat.format(new Date(vValue), true);
						break;
					case "Edm.DateTimeOffset":
						sValue = this.oDateTimeOffsetFormat.format(new Date(vValue), true);
						break;
					case "Edm.Guid":
						sValue = "guid'" + vValue + "'";
						break;
					case "Edm.Decimal":
						sValue = vValue + "M";
						break;
					case "Edm.Int64":
						sValue = vValue + "L";
						break;
					case "Edm.Double":
						sValue = vValue + "d";
						break;
					case "Edm.Float":
					case "Edm.Single":
						sValue = vValue + "f";
						break;
					case "Edm.Binary":
						sValue = "binary'" + vValue + "'";
						break;
					default:
						sValue = String(vValue);
						break;
				}
				return sValue;
			},

			_createUpdateQueries: function(sPath, sSchemaName) {
				var sUpdatePath = sPath + "/crud/Update/RequestData";
				var oModel = this._oComponent.getModel();
				var aRequestData = oModel.getProperty(sUpdatePath);
				var aUpdateQueries = [];

				var aPaths = [];
				// Get EntitySet
				var oEntitySet = oModel.getProperty(sPath);

				for (var i = 0; i < aRequestData.length; i++) {
					if (!aRequestData[i].DataEntered || !aRequestData[i].Valid) {
						continue;
					}

					var oQuerySample = $.extend(true, {}, this._getQuerySampleObject());
					// Create Query Object
					oQuerySample["Source"].EntitySet = oEntitySet.name;
					oQuerySample["Source"].Schema = sSchemaName;
					oQuerySample.HTTPMethod = "PUT";
					oQuerySample.CRUDType = "Update";
					oQuerySample.CRUDModelPath = sUpdatePath + "/" + i;

					// Form PayLoad
					var oPayload = {};
					for (var j = 0; j < aRequestData[i].property.length; j++) {
						var sValue = this._parseValueBasedOnType(aRequestData[i].property[j].value, aRequestData[i].property[j].type, aRequestData[i].property[
							j].key);
						if (aRequestData[i].property[j].key) {
							var sPath = "";
							sPath = aRequestData[i].property[j].name + "=" + sValue;
							aPaths.push(sPath);
						}

						if (sValue !== undefined && oEntitySet["crud"]["Update"].PayloadType === "02") {
							oPayload[aRequestData[i].property[j].name] = sValue;
						} else if (oEntitySet["crud"]["Update"].PayloadType === "01" && aRequestData[i].property[j].value) {
							oPayload[aRequestData[i].property[j].name] = sValue;
						}
					}

					// Form path
					var sUpdatePath = aPaths.join(",");
					oQuerySample.SampleDataPath = oEntitySet.name + "(" + sUpdatePath + ")";

					oQuerySample.RequestData.Data = oPayload;
					aUpdateQueries.push(oQuerySample);
				}

				return aUpdateQueries;
			},

			_createDeleteQueries: function(sPath, sSchemaName) {
				var sUpdatePath = sPath + "/crud/Delete/RequestData";
				var oModel = this._oComponent.getModel();
				var aRequestData = oModel.getProperty(sUpdatePath);
				var aDeleteQueries = [];

				var aPaths = [];
				// Get EntitySet
				var oEntitySet = oModel.getProperty(sPath);

				for (var i = 0; i < aRequestData.length; i++) {
					if (!aRequestData[i].DataEntered || !aRequestData[i].Valid) {
						continue;
					}

					var oQuerySample = $.extend(true, {}, this._getQuerySampleObject());
					// Create Query Object
					oQuerySample["Source"].EntitySet = oEntitySet.name;
					oQuerySample["Source"].Schema = sSchemaName;
					oQuerySample.HTTPMethod = "DELETE";
					oQuerySample.CRUDType = "Delete";
					oQuerySample.CRUDModelPath = sUpdatePath + "/" + i;

					for (var j = 0; j < aRequestData[i].property.length; j++) {
						var sValue = this._parseValueBasedOnType(aRequestData[i].property[j].value, aRequestData[i].property[j].type, aRequestData[i].property[
							j].key);
						if (aRequestData[i].property[j].key) {
							var sPath = "";
							sPath = aRequestData[i].property[j].name + "=" + sValue;
							aPaths.push(sPath);
						}
					}

					// Form path
					var sDeletePath = aPaths.join(",");
					oQuerySample.SampleDataPath = oEntitySet.name + "(" + sDeletePath + ")";

					aDeleteQueries.push(oQuerySample);
				}

				return aDeleteQueries;
			},

			modifyQuery: function(sCreateRequestPath, sQueryPath, sCRUDType) {
				var oModel = this._oComponent.getModel();
				var oRequestData = oModel.getProperty(sCreateRequestPath);

				var iStringEnd = sCreateRequestPath.indexOf("/RequestData");
				var sCRUDEntitySetPath = sCreateRequestPath.substring(0, iStringEnd);

				// Change the PayLoad
				var oPayload = {},
					oEntitySet = oModel.getProperty(sCRUDEntitySetPath);
				var aPaths = [];
				for (var j = 0; j < oRequestData.property.length; j++) {
					var
						sValue = this._parseValueBasedOnType(oRequestData.property[j].value, oRequestData.property[j].type, oRequestData.property[j].key);

					if (sCRUDType !== "POST" && oRequestData.property[j].key) {
						var sPath = "";
						sPath = oRequestData.property[j].name + "=" + sValue;
						aPaths.push(sPath);
					}
					if (sValue !== undefined && oEntitySet.PayloadType === "02") {
						oPayload[oRequestData.property[j].name] = sValue;
					} else if (oEntitySet.PayloadType === "01" && oRequestData.property[j].value) {
						oPayload[oRequestData.property[j].name] = sValue;
					}
				}

				// Form path
				if (sCRUDType !== "POST") {
					var sNewPath = oRequestData.name + "(" + aPaths.join(",") + ")";
					this._oComponent.getModel("QueryModel").setProperty(sQueryPath + "/SampleDataPath", sNewPath);
				}
				this._oComponent.getModel("QueryModel").setProperty(sQueryPath + "/RequestData/Data", oPayload);
			},

			_createCreateQueries: function(sPath, sSchemaName) {
				var sCreatePath = sPath + "/crud/Create/RequestData";
				var oModel = this._oComponent.getModel();
				var aRequestData = oModel.getProperty(sCreatePath);
				var aCreateQueries = [];

				// Get EntitySet
				var oEntitySet = oModel.getProperty(sPath);

				for (var i = 0; i < aRequestData.length; i++) {
					if (!aRequestData[i].DataEntered || !aRequestData[i].Valid) {
						continue;
					}
					var oQuerySample = $.extend(true, {}, this._getQuerySampleObject());
					// Create Query Object
					oQuerySample["Source"].EntitySet = oEntitySet.name;
					oQuerySample["Source"].Schema = sSchemaName;
					oQuerySample.HTTPMethod = "POST";
					oQuerySample.CRUDType = "Create";
					oQuerySample.CRUDModelPath = sCreatePath + "/" + i;

					// Form path
					oQuerySample.SampleDataPath = oEntitySet.name;

					// Form PayLoad
					var oPayload = {};
					for (var j = 0; j < aRequestData[i].property.length; j++) {
						var sValue = this._parseValueBasedOnType(aRequestData[i].property[j].value, aRequestData[i].property[j].type, aRequestData[i].property[
							j].key);

						if (sValue !== undefined && oEntitySet["crud"]["Create"].PayloadType === "02") {
							oPayload[aRequestData[i].property[j].name] = sValue;
						} else if (oEntitySet["crud"]["Create"].PayloadType === "01" && aRequestData[i].property[j].value) {
							oPayload[aRequestData[i].property[j].name] = sValue;
						}
					}
					oQuerySample.RequestData.Data = oPayload;
					aCreateQueries.push(oQuerySample);
				}

				return aCreateQueries;
			},

			_createReadQueries: function(sPath, sSchemaName) {
				var sReadPath = sPath + "/crud/Read/RequestData";
				var oModel = this._oComponent.getModel();
				var aRequestData = oModel.getProperty(sReadPath);
				var aReadQueries = [];

				// Get EntitySet
				var oEntitySet = oModel.getProperty(sPath);

				for (var i = 0; i < aRequestData.length; i++) {
					// Data Entered is true for Below Conditions
					// 1. If Read Only checkbox is selected
					// 2. If filter property / value has changed
					// 3. If Select property is entered
					// 4. If Sorter is entered
					var bDataEntered = false;
					var aFilters = aRequestData[i].Filter;
					var aSelectProperties = aRequestData[i].Select;
					var aSorterAsc = aRequestData[i].SorterAsc;
					var aSorterDesc = aRequestData[i].SorterDesc;

					if (aRequestData[i].OnlyRead || (aSelectProperties && aSelectProperties.length > 0) || (aSorterAsc && aSorterAsc.length > 0) ||
						(aSorterDesc && aSorterDesc.length > 0)) {
						bDataEntered = true;
					} else if (aFilters && aFilters.length > 0) {
						for (var j = 0; aFilters && j < aFilters.length; j++) {
							if (aFilters[j].Value1) {
								bDataEntered = true;
							}
						}
					} else {
						continue;
					}

					var oQuerySample = $.extend(true, {}, this._getQuerySampleObject());
					// Create Query Object
					oQuerySample["Source"].EntitySet = oEntitySet.name;
					oQuerySample["Source"].Schema = sSchemaName;
					oQuerySample.HTTPMethod = "GET";
					oQuerySample.CRUDType = "Read";
					oQuerySample.CRUDModelPath = sReadPath + "/" + i;

					// Form path
					if (aRequestData[i].OnlyRead && bDataEntered) {
						oQuerySample.SampleDataPath = oEntitySet.name;
					} else if ((!aRequestData[i].OnlyRead) && bDataEntered) {
						// Check for Filters
						var sFilterPath = "";
						var sParsedFilterPath = this._formFilterQuery(0, "", aFilters);

						// Form Select Path
						var sSelectPropertyPath = aSelectProperties.join(",");

						// Form Expand Path
						var sExpandPath = "";
						if (aFilters && aFilters.length > 0) {
							var aExpandEntities = aRequestData[i].Expand;
							sExpandPath = aExpandEntities.join(",");
						}

						// Create Sorting Path
						var sSortingPath = "";
						sSortingPath = sSortingPath + this._createSortQuery(aSorterAsc, false /*bDescending*/ );
						sSortingPath = sSortingPath + this._createSortQuery(aSorterDesc, true /*bDescending*/ );

						var sFullReadPath = oEntitySet.name;

						if (sFullReadPath.indexOf("?") === -1 && sParsedFilterPath) {
							sFullReadPath = sFullReadPath + "?$filter=" + sParsedFilterPath;
						} else if (sParsedFilterPath) {
							sFullReadPath = sFullReadPath + "&$filter=" + sParsedFilterPath;
						}

						if (sFullReadPath.indexOf("?") === -1 && sSelectPropertyPath) {
							sFullReadPath = sFullReadPath + "?$select=" + sSelectPropertyPath;
						} else if (sSelectPropertyPath) {
							sFullReadPath = sFullReadPath + "&$select=" + sSelectPropertyPath;
						}

						if (sFullReadPath.indexOf("?") === -1 && sExpandPath) {
							sFullReadPath = sFullReadPath + "?$expand=" + sExpandPath;
						} else if (sExpandPath) {
							sFullReadPath = sFullReadPath + "&$expand=" + sExpandPath;
						}

						if (sFullReadPath.indexOf("?") === -1 && sSortingPath) {
							sFullReadPath = sFullReadPath + "?$orderby=" + sSortingPath;
						} else if (sExpandPath) {
							sFullReadPath = sFullReadPath + "&$orderby=" + sSortingPath;
						}

						if (sFullReadPath !== oEntitySet.name) {
							oQuerySample.SampleDataPath = sFullReadPath;
						}
					}

					if (oQuerySample.SampleDataPath) {
						aReadQueries.push(oQuerySample);
					}
				}

				return aReadQueries;
			},

			/**
			 * 
			 * 
			 */
			_formFilterQuery: function(iFilterCount, sFilterPath, aFilters) {
				if (iFilterCount === aFilters.length) {
					return "";
				}

				var bAndOperator = aFilters[iFilterCount - 1] ? aFilters[iFilterCount - 1].bAnd : null;
				var sFilterOperator = "";

				if (bAndOperator === true) {
					sFilterOperator = "%20and%20";
				} else if (bAndOperator === false) {
					sFilterOperator = "%20or%20";
				} else {
					sFilterOperator = "";
				}

				if (aFilters[iFilterCount].Type === "Single") {
					sFilterPath = sFilterOperator + this._formFilterPath(aFilters[iFilterCount]);
					return sFilterPath + this._formFilterQuery(++iFilterCount, sFilterPath, aFilters);
				} else {
					var aSubFilters = aFilters[iFilterCount].SubFilters;
					sFilterPath = sFilterOperator + "(" + this._formFilterPath(aFilters[iFilterCount]);
					return sFilterPath + this._formFilterQuery(0, sFilterPath, aSubFilters) + ")";
				}
			},

			/**
			 * 
			 * 
			 */
			_createSortQuery: function(aSorters, bDescending) {
				if (!aSorters || aSorters.length == 0) {
					return "";
				}

				var sPath = "";
				for (var i = 0; i < aSorters.length; i++) {
					sPath = sPath + aSorters[i] + (bDescending ? "%20desc%20" : "%20asc%20") + ",";
				}
				sPath = sPath.slice(0, -1);

				return sPath;
			},

			/**
			 *
			 * 
			 */
			enhanceModelToAddCRUDObject: function(sModelName) {
				var oModel;
				if (!sModelName) {
					oModel = this._oComponent.getModel();
				} else {
					oModel = this._oComponent.getModel(sModelName);
				}

				var aSchema = oModel.getProperty("/schema");

				// TODO : use Enums for PayLoadType
				for (var i = 0; i < aSchema.length; i++) {
					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {
						// Enhance the existing main Model for CRUD
						// TODO : Check :Consider only one EntityContainer ? use DefaultContainer property else take first one
						var aEntitySets = oModel.getProperty("/schema/" + i + "/entityContainer/0/entitySet");
						for (var j = 0; j < aEntitySets.length; j++) {
							oModel.setProperty("/schema/" + i + "/entityContainer/0/entitySet/" + j + "/crud", {
								Reject: false,
								Create: {
									Available: true,
									RequestData: [],
									PayloadType: "01"
								},
								Update: {
									Available: true,
									RequestData: [],
									PayloadType: "01"
								},
								Read: {
									Available: true,
									RequestData: []
								},
								Delete: {
									Available: true,
									RequestData: []
								}
							});
						}

					}
				}

			},

			/**
			 * 
			 * 
			 * 
			 */
			getCSRFToken: function() {
				// get the token from the OData model attached to the component
				var sToken = "";

				try {
					sToken = this._oComponent.getModel("oDataModel").getSecurityToken() ? this._oComponent.getModel("oDataModel").getSecurityToken() :
						"";
				} catch (e) {
					sToken = "";
				}

				if (sToken && sToken.length === 0) {
					// if the token is not available, then refresh the token
					this._oComponent.getModel("oDataModel").refreshSecurityToken();
					// re-attempt security token fetch
					sToken = this._oComponent.getModel("oDataModel").getSecurityToken();
				}

				return sToken;
			},

			/**
			 * Generates a Tree with the given OData
			 * 
			 * @param: {string} sRootName Name of the Root Node {object} oData Model whose tree is to be generated
			 * @memberOf: sap.cd.ODataTracker.util.ModelHelper
			 */
			getTreeModel: function(sRootName, oData) {
				var oModelData = {
					nodes: []
				};
				// Creating the First Level
				var oFirstLevel = {
					text: sRootName,
					filterProperty: sRootName,
					nodes: []
				};

				oModelData.nodes.push(oFirstLevel);
				this.addNodesToModel(oFirstLevel.nodes, oData, sRootName);

				return oFirstLevel;
			},

			/**
			 * Recursive Function that adds nodes to the given node
			 * 
			 * @param: {array} oNode Node to which further nodes are to be recursively added {object} oData Model whose tree is to be generated
			 *         {string} sParent Parent Object
			 * @memberOf: sap.cd.ODataTracker.util.ModelHelper
			 */
			addNodesToModel: function(oNode, oData, sParent) {
				var sText = "";
				var sPassParent = "";
				var sFilterProperty = "";

				// Adding namespace and name to the filter property
				if (oData["namespace"] !== undefined) {
					sParent = sParent + "_" + oData["namespace"];
				}
				if (oData["name"] !== undefined) {
					sParent = sParent + "_" + oData["name"];
				}

				for (var i = 0; Object.keys(oData)[i] !== undefined; i++) {
					// If the node has no further nodes
					if (typeof(oData[Object.keys(oData)[i]]) !== "object") {
						sText = Object.keys(oData)[i] + " : " + oData[Object.keys(oData)[i]];
						sPassParent = sParent;

						// Setting the filter property
						sFilterProperty = sParent + "_" + Object.keys(oData)[i] + "_" + oData[Object.keys(oData)[i]];
						// Making it case insensitive
						sFilterProperty.toLowerCase();

						// Creating the node with the properties
						var oSubNode = {
							text: sText,
							filterProperty: sFilterProperty
						};
						oNode.push(oSubNode);
					} else {
						// If the node has further nodes
						if (oData[Object.keys(oData)[i]] !== null) {
							// If the node is an array
							if (oData[Object.keys(oData)[i]].length) {
								sText = Object.keys(oData)[i] + " : Array[" + oData[Object.keys(oData)[i]].length + "]";
								sPassParent = sParent + "_" + Object.keys(oData)[i];
							} else {
								// If the node is an object
								if (typeof(oData[Object.keys(oData)[i]]) === "object") {
									sText = Object.keys(oData)[i] + " : Object";
									sPassParent = sParent;
								}
							}
						} else {
							// If the node has a null value
							sText = Object.keys(oData)[i] + " : " + oData[Object.keys(oData)[i]];
							sPassParent = sParent;
						}

						// Setting the filter property
						if (typeof(oData[Object.keys(oData)[i]]) !== "object") {
							sFilterProperty = sParent + "_" + Object.keys(oData)[i] + "_" + oData[Object.keys(oData)[i]];
						} else {
							sFilterProperty = sParent + "_" + Object.keys(oData)[i];
						}
						// Making it case insensitive
						sFilterProperty.toLowerCase();

						// Creating the node with the properties
						var oSubNode = {
							text: sText,
							filterProperty: sFilterProperty
						};
						oNode.push(oSubNode);
						oSubNode.nodes = [];

						// Passing the node to the recursive function to add further nodes to it
						if ((typeof(oData[Object.keys(oData)[i]]) === "object") && (oData[Object.keys(oData)[i]] !== null)) {
							this.addNodesToModel(oSubNode.nodes, oData[Object.keys(oData)[i]], sPassParent);
						}
					}
				}
			}
		});
	});
}());