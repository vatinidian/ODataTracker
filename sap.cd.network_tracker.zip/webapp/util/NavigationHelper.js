(function() {
	"use strict";
	sap.ui.define([], function() {
		sap.ui.base.Object.extend("sap.cd.ODataTracker.util.NavigationHelper", {
			// reference to component
			_oComponent: null,

			_oNavTabContainer: null,

			/**
			 * Map For Route to Screen Name TODO : use from main Model
			 */
			TargetsScreenName: {
				MetadataConfig: "Service Overview",
				SampleDataConfig: "SampleData Configuration",
				NetworkRequest: "NetworkRequest"
			},

			/**
			 * 
			 */
			constructor: function(oComponent) {
				this._oComponent = oComponent;
			},

			/**
			 * Helper method to create Navigation tabs
			 */
			createNavigationTabs: function(oContainer) {
				var oModel = this._oComponent.getModel();
				var aNavgiationTabs = oModel.getProperty("/NavigationTab");

				this._oNavTabContainer = oContainer;

				for (var i = 0; i < aNavgiationTabs.length; i++) {
					var oButton = new sap.m.Button({
						icon: "{/NavigationTab/" + i + "/Icon}",
						enabled: "{/NavigationTab/" + i + "/Enabled}",
						customData: [
							{
								Type: "sap.ui.core.CustomData",
								key: "TabName",
								value: "{/NavigationTab/" + i + "/Name}"
							}, {
								Type: "sap.ui.core.CustomData",
								key: "TargetRoute",
								value: "{/NavigationTab/" + i + "/TargetRoute}"
							}
						],
						press: $.proxy(this.handleNavigationTabPress, this)
					});

					if (aNavgiationTabs[i].CurrentFocus) {
						oButton.addStyleClass("oDataNavButtonActive");
					} else {
						oButton.addStyleClass("oDataNavButton");
					}

					oContainer.addContent(oButton);

					if (i < aNavgiationTabs.length - 1) {
						// Create Line
						var oLine = new sap.ui.core.HTML({
							content: "<div class='oDataNavLine' />"
						});
						oContainer.addContent(oLine);
					}

				}
				
				// TODO : Find right place
				// this._oConfirmationDialog = sap.ui.xmlfragment("confirmationDialog", "sap.cd.ODataTracker.view.fragment.ConfirmationDialog", this);
			},

			/**
			 * 
			 * 
			 */
			handleNavigationTabPress: function(oEvent) {
				// var oController = this;
				var oTab = oEvent.getSource();
				var sTabName = oTab.data("TabName");
				var sTargetRoute = oTab.data("TargetRoute");
				var oModel = this._oComponent.getModel();
				var sPreviousTabName = oModel.getProperty("/CurrentScreen/TabName");
				this._oConfirmationDialogOpen = false;

				// Showing Confirmation Dialog while navigating away from Network Request page or Analyze Page
				if (sPreviousTabName === "NetworkRequest") {
					this._oTab = oTab;
					if (oModel.getProperty("/CurrentScreen/TabName") === sTabName) {
						return;
					}

					if (!this._oConfirmationDialog) {
						this._oConfirmationDialog = sap.ui.xmlfragment("confirmationDialog", "sap.cd.ODataTracker.view.fragment.ConfirmationDialog", this);
						this._oConfirmationDialog.setModel(this._oComponent.getModel("i18n"), "i18n");
					}
					this._oConfirmationDialog.open();
					this._oConfirmationDialogOpen = true;
				}
				if (oModel.getProperty("/CurrentScreen/TabName") === sTabName) {
					return;
				}

				if (!this._oConfirmationDialogOpen) {
					// Change Tab Style
					this._changeNavigationButtonTabStates(oTab);

					oModel.setProperty("/CurrentScreen/Name", this.TargetsScreenName[sTabName]);
					oModel.setProperty("/CurrentScreen/RouteName", sTargetRoute);
					oModel.setProperty("/CurrentScreen/TabName", sTabName);

					// Using Targets to navigate , since we dont want to use Hash change in URL (to avoid bookmarking)
					var that = this;
					var oMainView = this._oComponent.getAggregation("rootControl");
					oMainView.setBusyIndicatorDelay(0);
					oMainView.setBusy(true);
					window.setTimeout(function() {
						that._oComponent.getRouter().getTargets().display(sTargetRoute);
						oMainView.setBusy(false);
					}, 0);
				}

				// Refreshing the Model for the Tree on Dynamic Side Content
				var oSchema = oModel.oData.schema;;
				
				var oModelHelper = this._oComponent.getModelHelper();
				var oTreeData = oModelHelper.getTreeModel("schema", oSchema);
				
				var oTreeModel = this._oComponent.getModel("treeModel");
				oTreeModel.setData(oTreeData);
			},

			/**
			 * Handles the Press Event of the Yes Button of the Confirmation Dialog
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.util.NavigationHelper
			 */
			handleConfirmationDialogYes: function(oEvent) {
				var sTabName = this._oTab.data("TabName");
				var sTargetRoute = this._oTab.data("TargetRoute");
				var oModel = this._oComponent.getModel();

				// Change Tab Style
				this._changeNavigationButtonTabStates(this._oTab);

				oModel.setProperty("/CurrentScreen/Name", this.TargetsScreenName[sTabName]);
				oModel.setProperty("/CurrentScreen/RouteName", sTargetRoute);
				oModel.setProperty("/CurrentScreen/TabName", sTabName);

				// Using Targets to navigate
				var that = this;
				var oMainView = this._oComponent.getAggregation("rootControl");
				oMainView.setBusyIndicatorDelay(0);
				oMainView.setBusy(true);
				window.setTimeout(function() {
					that._oComponent.getRouter().getTargets().display(sTargetRoute);
					oMainView.setBusy(false);
				}, 0);
				
				this._oConfirmationDialog.close();
				this._oConfirmationDialogOpen = false;
			},

			/**
			 * Handles the Press Event of the No Button of the Confirmation Dialog
			 * 
			 * @memberOf: sap.cd.ODataTracker.util.NavigationHelper
			 */
			handleConfirmationDialogNo: function() {
				this._oConfirmationDialog.close();
				this._oConfirmationDialogOpen = false;
			},

			/**
			 * 
			 */
			_changeNavigationButtonTabStates: function(oTab) {
				oTab.setEnabled(true);

				// Get Navigation Container (which contains all Buttons)
				var aTabs = this._oNavTabContainer.getContent();
				var oLastLine = null;
				for (var i = 0; i < aTabs.length; i++) {
					if (aTabs[i] instanceof sap.m.Button) {
						if (aTabs[i] !== oTab) {
							aTabs[i].removeStyleClass("oDataNavButtonActive");
							aTabs[i].addStyleClass("oDataNavButton");
							
							if(aTabs[i].getEnabled() && oLastLine) {
								oLastLine.setContent("<div class='oDataNavLineActive' />");
							}	
						} else {

							if (oLastLine) {
								oLastLine.setContent("<div class='oDataNavLineActive' />");
							}

							aTabs[i].addStyleClass("oDataNavButtonActive");
							aTabs[i].removeStyleClass("oDataNavButton");

							// TODO : Update the model currentFocus and Enabled
							this.setNavTabAsCurrentFocus(aTabs[i].data("TabName"));
						}
					} else if (aTabs[i] instanceof sap.ui.core.HTML) {
						oLastLine = aTabs[i];
					}

				}
			},

			/**
			 * 
			 * 
			 */
			resetNavTabsToInitialState: function() {
				// Get Navigation Container (which contains all Buttons)
				var aNavItems = this._oNavTabContainer.getContent();

				// First Tab is active by Default
				var oFirstTab = aNavItems[0];
				oFirstTab.setEnabled(true);
				oFirstTab.addStyleClass("oDataNavButtonActive");
				oFirstTab.removeStyleClass("oDataNavButton");
				this.setNavTabAsCurrentFocus(oFirstTab.data("TabName"));

				for (var i = 1; i < aNavItems.length; i++) {
					if (aNavItems[i] instanceof sap.m.Button) {
						aNavItems[i].removeStyleClass("oDataNavButtonActive");
						aNavItems[i].addStyleClass("oDataNavButton");
						aNavItems[i].setEnabled(false);

					} else if (aNavItems[i] instanceof sap.ui.core.HTML) {
						aNavItems[i].setContent("<div class='oDataNavLine' />");
					}
				}
			},

			/**
			 * 
			 */
			enableNextStep: function(sCurrentTabName) {
				var oModel = this._oComponent.getModel();
				var aNavTabs = oModel.getProperty("/NavigationTab");
				var bEnableNextTab = false;

				for (var i = 0; i < aNavTabs.length; i++) {
					if (bEnableNextTab) {
						oModel.setProperty("/NavigationTab/" + i + "/Enabled", true);
						bEnableNextTab = false;
					}

					if (aNavTabs[i].Name === sCurrentTabName) {
						bEnableNextTab = true;
					}
				}
			},

			setNavTabAsCurrentFocus: function(sCurrentTabName) {
				var oModel = this._oComponent.getModel();
				var aNavTabs = oModel.getProperty("/NavigationTab");

				for (var i = 0; i < aNavTabs.length; i++) {
					if (aNavTabs[i].Name === sCurrentTabName) {
						oModel.setProperty("/NavigationTab/" + i + "/CurrentFocus", true);
					} else {
						oModel.setProperty("/NavigationTab/" + i + "/CurrentFocus", false);
					}
				}
			},
			/**
			 * 
			 */
			disableNextSteps: function(sTabName) {
				var aContainerItems = this._oNavTabContainer.getContent();
				var bDisable = false;

				for (var i = 0; i < aContainerItems.length; i++) {
					if (aContainerItems[i] instanceof sap.m.Button) {
						if (bDisable) {
							aContainerItems[i].removeStyleClass("oDataNavButtonActive");
							aContainerItems[i].addStyleClass("oDataNavButton");
							aContainerItems[i].setEnabled(false);
						} else {
							var sCurrentTabName = aContainerItems[i].data("TabName");
							if (sCurrentTabName === sTabName) {
								this.setNavTabAsCurrentFocus(sCurrentTabName);
								aContainerItems[i].setEnabled(true);
								bDisable = true;
							}
						}
					} else if (aContainerItems[i] instanceof sap.ui.core.HTML && bDisable) {
						aContainerItems[i].setContent("<div class='oDataNavLine' />");
					}
				}
			},

			/**
			 * 
			 */
			goToNavTab: function(sTabName) {
				var aContainerItems = this._oNavTabContainer.getContent();
				for (var i = 0; i < aContainerItems.length; i++) {
					var sCurrentTabName = aContainerItems[i].data("TabName");
					if (sCurrentTabName === sTabName) {
						this._changeNavigationButtonTabStates(aContainerItems[i]);
						return;
					}
				}
			}

		});
	});
})();