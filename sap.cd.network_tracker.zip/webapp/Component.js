sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/cd/ODataTracker/model/models",
	"sap/ui/model/resource/ResourceModel", 
	"sap/ui/model/json/JSONModel"
], function(UIComponent, Device, models, ResourceModel, JSONModel) {
	"use strict";

	return UIComponent.extend("sap.cd.ODataTracker.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			// Main Model
			var oMainModelData = {
				ModelChanged: false,
				ModelLoadedFromFile: false,
				ServiceURLChanged: false,
				ProjectTitle: "",
				ConfigurationFileUsed: false,
				bDownloadConfiguration: true,
				bServiceURLUsed: true,
				ServiceUrl: "",
				RelativeURL: false,
				FilterOperators: [{
					OperatorName: "Equals",
					OperatorKey: "eq",
					AllowedTypes: []
				}, {
					OperatorName: "Not Equals",
					OperatorKey: "ne",
					AllowedTypes: []
				}, {
					OperatorName: "Contains",
					OperatorKey: "Contains",
					AllowedTypes: []
				}, {
					OperatorName: "Between",
					OperatorKey: "bt",
					AllowedTypes: []
				}, {
					OperatorName: "EndsWith",
					OperatorKey: "endswith",
					AllowedTypes: []
				}, {
					OperatorName: "Greater Or Equals",
					OperatorKey: "ge",
					AllowedTypes: []
				}, {
					OperatorName: "Greater Than",
					OperatorKey: "gt",
					AllowedTypes: []
				}, {
					OperatorName: "Lesser or Equals",
					OperatorKey: "le",
					AllowedTypes: []
				}, {
					OperatorName: "Lesser Than",
					OperatorKey: "lt",
					AllowedTypes: []
				}, {
					OperatorName: "StartsWith",
					OperatorKey: "startswith",
					AllowedTypes: []
				}],
				CurrentScreen: {
					Name: "Service Overview",
					RouteName: "MetadataConfig",
					TabName: "MetadataConfig"
				},
				Screens: {
					MetadataConfig: "Service Overview",
					SampleDataConfig: "SampleData Configuration",
					NetworkRequest: "NetworkRequest",
					Analyse: "Analyse"
				},
				NavigationTab: [{
					Name: "MetadataConfig",
					Enabled: true,
					Active: true,
					CurrentFocus: true,
					TargetRoute: "MetadataConfig",
					Icon: "sap-icon://download"
				}, {
					Name: "SampleDataConfig",
					Enabled: false,
					Active: false,
					CurrentFocus: false,
					TargetRoute: "SampleDataConfig",
					Icon: "sap-icon://database"
				}, {
					Name: "NetworkRequest",
					Enabled: false,
					Active: false,
					CurrentFocus: false,
					TargetRoute: "NetworkRequest",
					Icon: "sap-icon://internet-browser"
				}],
				Settings: {

				}
			};
			var oJSONModel = new JSONModel(oMainModelData);
			this.setModel(oJSONModel);

			// Call parent constructor.
			sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

			// Initialize router
			var oRouter = this.getRouter();
			$.sap.delayedCall(0, this, function() {
				oRouter.initialize();
			});

			// For Drag And Drop
			$.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-core');
			$.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-widget');
			$.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-mouse');
			$.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-draggable');
			$.sap.require('sap.ui.thirdparty.jqueryui.jquery-ui-droppable');

			// Create Tree Model
			var oTreeModel = new JSONModel();
			this.setModel(oTreeModel, "treeModel");
		},
		getModelHelper: function() {
			$.sap.require("sap.cd.ODataTracker.util.ModelHelper");
			var oModelHelper = new sap.cd.ODataTracker.util.ModelHelper(this);
			// TODO : test
			this.getModelHelper = function() {
				return oModelHelper;
			};
			return oModelHelper;
		},

		getNavigationHelper: function() {
			$.sap.require("sap.cd.ODataTracker.util.NavigationHelper");
			var oNavigationHelper = new sap.cd.ODataTracker.util.NavigationHelper(this);
			// TODO : test
			this.getNavigationHelper = function() {
				return oNavigationHelper;
			};
			return oNavigationHelper;
		},

		destroy: function() {
			sap.ui.core.UIComponent.destroy.apply(this, arguments);
		}
	});

});