(function() {
	sap.ui.define([
		"sap/cd/ODataTracker/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/cd/ODataTracker/util/CommonHelper"
	], function(BaseController, JSONModel, CommonHelper) {
		return BaseController.extend("sap.cd.ODataTracker.controller.TriggerNWCalls", {
			onInit: function() {
				this._oNetworkConsoleFragment = null;
				this._iCurrentSelectedIndex = 0;

				var oRouter = this.getRouter();
				oRouter.getTargets().attachDisplay(null, this._onRouteMatched, this);

				var oResponseTreeModel = new JSONModel();
				this.getView().setModel(oResponseTreeModel, "ResponseTree");
				this._oParameterListTemplate = new sap.m.ColumnListItem({
					cells: [new sap.m.Text({
						text: "{QueryModel>key}"
					}), new sap.m.Text({
						text: "{QueryModel>value}"
					})]
				});

				var oViewModel = new JSONModel({
					ParamEdit: false,
					Error: false,
					ParamRead : false
				});
				this.getView().setModel(oViewModel, "TriggerCalls");

			},

			/**
			 * 
			 */
			_onRouteMatched: function(oEvent) {
				if (oEvent.getParameter("name") !== "NetworkRequest") {
					return;
				}

				var oFixFlex = this.byId("triggerNWFlexContent");
				oFixFlex.setFixContentSize("auto");

				this.getComponent().getModelHelper().createQueryModel();
				this.byId("triggerNWTable").bindRows("QueryModel>/Queries");
			},

			handleSelectionMode: function(oEvent) {
				var oButton = oEvent.getSource();
				var oNWTable = this.byId("triggerNWTable");
				if (oButton.getPressed()) {
					oButton.setIcon("sap-icon://multi-select");
					oNWTable.setSelectionMode(sap.ui.table.SelectionMode.MultiToggle);
				} else {
					oButton.setIcon("sap-icon://multiselect-none");
					oNWTable.setSelectionMode(sap.ui.table.SelectionMode.Single);
				}
			},
			formatIconSource: function(iStatus) {
				if (iStatus === 400 || iStatus === 500 || iStatus === 404 || iStatus === 501 || iStatus === 503 || iStatus === 403) {
					return "sap-icon://message-error";
				} else if (iStatus === 200 || iStatus === 201 || iStatus === 204 || iStatus === 202) {
					return "sap-icon://message-success";
				}
			},

			formatIconState: function(iStatus) {
				if (iStatus === 400 || iStatus === 500 || iStatus === 404 || iStatus === 501 || iStatus === 503 || iStatus === 403) {
					return sap.ui.core.ValueState.Error;
				} else if (iStatus === 200 || iStatus === 201 || iStatus === 204 || iStatus === 202) {
					return sap.ui.core.ValueState.Success;
				}
			},

			clearSelection: function() {
				this.byId("triggerNWTable").clearSelection();
				var oFixFlex = this.byId("triggerNWFlexContent");
				oFixFlex.setFixContentSize("auto");
			},

			handleRowSelection: function(oEvent) {
				var oSource = oEvent.getSource();
				var oFixFlex = this.byId("triggerNWFlexContent");
				if (oSource.getSelectedIndex() !== -1 && oSource.getSelectedIndices().length === 1) {
					if (!this._oNetworkConsoleFragment) {
						this._oNetworkConsoleFragment = new sap.ui.xmlfragment("networkConsole", "sap.cd.ODataTracker.view.fragment.NetworkConsole",
							this);
						this.getView().addDependent(this._oNetworkConsoleFragment);
						oFixFlex.setFlexContent(this._oNetworkConsoleFragment);
					}

					sap.ui.core.Fragment.byId("networkConsole", "networkConsoleIconTab").bindElement({
						path: oSource.getRows()[oSource.getSelectedIndex()].getBindingContext("QueryModel").getPath(),
						model: 'QueryModel'
					});

					if (!this._oPayloadTypeCombo) {
						this._oPayloadTypeCombo = sap.ui.core.Fragment.byId("networkConsole", "payloadType");
					}
					this._iCurrentSelectedIndex = oSource.getSelectedIndex();
					var oContext = oSource.getContextByIndex(this._iCurrentSelectedIndex);
					var sContextPath = oContext.getPath();
					this._createRequestParams(sContextPath);
					if (oContext.getObject().HTTPMethod !== "GET") {
						this._createRequestParamsEditForm(oContext);
					} else {
						this._oPayloadTypeCombo.setVisible(false);
					}
					oFixFlex.setFixContentSize("70%");
				} else {
					oFixFlex.setFixContentSize("auto");
					this._iCurrentSelectedIndex = 0;
				}
			},

			triggerAllQueries: function() {
				this._triggerCalls(true);
			},

			triggerSelectedQueries: function() {
				this._triggerCalls(false);
			},

			/**
			 * TODO
			 */
			_triggerCalls: function(bFireAllQueries) {
				var oQueryModel = this.getComponent().getModel("QueryModel");
				var aQueries = oQueryModel.getProperty("/Queries");
				var oController = this;
				// Get Service URL
				var oModel = this.getComponent().getModel();
				var sServiceUrl = oModel.getProperty("/ServiceUrl");
				var sCRSFToken = this.getComponent().getModelHelper().getCSRFToken();

				var oHeaders = {};
				if (sCRSFToken) {
					oHeaders["x-csrf-token"] = sCRSFToken;
				}
				oHeaders["Accept"] = 'application/json';
				oHeaders["Content-Type"] = 'application/json';

				var oNWTable = this.byId("triggerNWTable");
				var aSelectedIndices = oNWTable.getSelectedIndices();
				var aSelectedContextPaths = [];

				if (!bFireAllQueries) {
					$.each(aSelectedIndices, function(iIndex, iEntry) {
						aSelectedContextPaths.push(oNWTable.getContextByIndex(iEntry).getPath());
					});
				}

				jQuery.each(aQueries, function(iIndex) {
					var sCurrentContextPath = "/Queries/" + iIndex;
					if (!(aQueries[iIndex].SampleDataPath) ||
						!(aQueries[iIndex].SampleDataPath.trim()) ||
						(!bFireAllQueries && (aSelectedContextPaths.length <= 0 || aSelectedContextPaths.indexOf(sCurrentContextPath) === -1))) {
						return;
					}

					var sPath = sServiceUrl + aQueries[iIndex].SampleDataPath;
					var sRequestData = "";
					if (aQueries[iIndex].RequestData && aQueries[iIndex].RequestData.Data) {
						sRequestData = JSON.stringify(aQueries[iIndex].RequestData.Data);
					}

					// TODO : Check whether service is from SAP Gateway and then add below flag
					if (sPath.indexOf("?") > -1) {
						sPath = sPath + "&sap-statistics=true";
					} else {
						sPath = sPath + "?sap-statistics=true";
					}

					var iStartTime = 0;
					oQueryModel.setProperty("/Queries/" + iIndex + "/Status", "Not Started");

					$.ajax({
						url: sPath,
						type: aQueries[iIndex].HTTPMethod,
						headers: oHeaders,
						data: sRequestData,
						dataType: "json", // TODO : make generic
						beforeSend: function() {
							iStartTime = new Date().getTime();
							oQueryModel.setProperty("/Queries/" + iIndex + "/Status", "Pending");
							oQueryModel.setProperty("/Queries/" + iIndex + "/StatusIndicator", true);
						},
						success: function(oResult, status, xhr) {
							var iRequestTime = new Date().getTime() - iStartTime;
							var fReqSeconds = parseFloat(iRequestTime / 1000);

							// var oResultData = oResult.value ? oResult.avlue : oResult.d.results;

							// var oModelHelper = oController.getComponent().getModelHelper();
							// var oTreeData = oModelHelper.getTreeModel("results", oResultData);
							// var oResonseModel = oController.getView().getModel("ResponseTree");
							// oResonseModel.setData(oTreeData);
							oQueryModel.setProperty("/Queries/" + iIndex + "/StatusIndicator", false);
							oQueryModel.setProperty("/Queries/" + iIndex + "/Status", xhr.status);
							oQueryModel.setProperty("/Queries/" + iIndex + "/StatusText", xhr.statusText);

							oQueryModel.setProperty("/Queries/" + iIndex + "/Response/Time", fReqSeconds + "s");
							oQueryModel.setProperty("/Queries/" + iIndex + "/Response/Data", oResult);
							oQueryModel.setProperty("/Queries/" + iIndex + "/Response/contentType", this.contentType);
							// Form Response Headers
							oController.setResponseHeaders(xhr, iIndex);

							oQueryModel.setProperty("/Queries/" + iIndex + "/RequestData/Headers", this.headers);
							oQueryModel.setProperty("/Queries/" + iIndex + "/RequestData/Accepts", this.accepts);
							oQueryModel.setProperty("/Queries/" + iIndex + "/RequestData/crossDomain", this.crossDomain);
							oQueryModel.setProperty("/Queries/" + iIndex + "/RequestData/dataType", this.dataType);

							oQueryModel.setProperty("/Queries/" + iIndex + "/Headers/URL", this.url);
							oQueryModel.setProperty("/Queries/" + iIndex + "/Headers/Method", this.type);
							oQueryModel.setProperty("/Queries/" + iIndex + "/Headers/Async", this.async);

							// oController._createRequestParams(iIndex);
							// Getting the SAP statistics from the response header
							var sStatisticsHeader = xhr.getResponseHeader("sap-statistics") ? xhr.getResponseHeader("sap-statistics") : xhr.getResponseHeader(
								"sapgw-statistics");

							// The following steps are done only if the sap-statistics header exist.
							if (sStatisticsHeader) {
								var oStaticsReading = {};
								// Parsing the header
								var aStatisticsTemp = sStatisticsHeader.split(",");
								for (var i = 0; i < aStatisticsTemp.length; i++) {
									var aStatistics = aStatisticsTemp[i].split("=");
									// If the value is a number then push it to an array
									oStaticsReading[aStatistics[0]] = aStatistics[1];
								}
								oQueryModel.setProperty("/Queries/" + iIndex + "/SAPStatistics", oStaticsReading);
							}
						},
						error: function(xhr) {
							var iRequestTime = new Date().getTime() - iStartTime;
							var fReqSeconds = parseFloat(iRequestTime / 1000);
							oQueryModel.setProperty("/Queries/" + iIndex + "/Response/Time", fReqSeconds + "s");

							oQueryModel.setProperty("/Queries/" + iIndex + "/Status", xhr.status);
							oQueryModel.setProperty("/Queries/" + iIndex + "/StatusText", xhr.statusText);
							oQueryModel.setProperty("/Queries/" + iIndex + "/StatusIndicator", false);

							// Form Response Headers
							oController.setResponseHeaders(xhr, iIndex);
						}
					});

				});
			},

			setResponseHeaders: function(xhr, iIndex) {
				var oQueryModel = this.getComponent().getModel("QueryModel");
				var aResponseHeaders = xhr.getAllResponseHeaders().split("\n");
				var aFormattedResponseHeaders = [];
				for (var i = 0; i < aResponseHeaders.length; i++) {
					if (aResponseHeaders[i]) {
						var aTempHeaders = aResponseHeaders[i].split(": ");
						aFormattedResponseHeaders.push({
							Key: aTempHeaders[0],
							Value: aTempHeaders[1]
						});
					}
				}

				// 
				if (aFormattedResponseHeaders.length <= 0) {
					oQueryModel.setProperty("/Queries/" + iIndex + "/Response/RawHeaders", xhr.getAllResponseHeaders());
					oQueryModel.setProperty("/Queries/" + iIndex + "/Response/Headers", []);
				} else {
					oQueryModel.setProperty("/Queries/" + iIndex + "/Response/Headers", aFormattedResponseHeaders);
					oQueryModel.setProperty("/Queries/" + iIndex + "/Response/RawHeaders", "");
				}
			},

			handleFilterPress: function(oEvent) {
				var oButton = oEvent.getSource();
				var oMethodSearchField = this.byId("methodSearchField");
				var oPathSearchField = this.byId("pathSearchField");
				var oSourceSearchField = this.byId("sourceSearchField");
				var oStatusSearchField = this.byId("statusSearchField");

				if (oButton.getPressed()) {
					oMethodSearchField.setVisible(true);
					oPathSearchField.setVisible(true);
					oSourceSearchField.setVisible(true);
					oStatusSearchField.setVisible(true);
				} else {
					oMethodSearchField.setVisible(false);
					oPathSearchField.setVisible(false);
					oSourceSearchField.setVisible(false);
					oStatusSearchField.setVisible(false);
				}

				this.byId("triggerNWTable").rerender();
			},

			/**
			 * Handles the Search Event of any of the four Search Fields in the columns of the table
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.TriggerNWCalls
			 */
			handleSearch: function() {
				// Fetching the queries from respective search fields
				var sPathQuery = this.byId("pathSearchField").getValue();
				var sEntityTypeQuery = this.byId("sourceSearchField").getValue();
				var sMethodQuery = this.byId("methodSearchField").getValue();
				var sStatusQuery = this.byId("statusSearchField").getValue();

				// Pushing the required filter into an array of filters
				var aFilters = [];
				if (sPathQuery) {
					aFilters.push(new sap.ui.model.Filter("SampleDataPath", sap.ui.model.FilterOperator.Contains, sPathQuery));
				}
				if (sEntityTypeQuery) {
					aFilters.push(new sap.ui.model.Filter("Source/EntitySet", sap.ui.model.FilterOperator.Contains, sEntityTypeQuery));
				}
				if (sMethodQuery) {
					aFilters.push(new sap.ui.model.Filter("HTTPMethod", sap.ui.model.FilterOperator.Contains, sMethodQuery));
				}
				if (sStatusQuery) {
					aFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, sStatusQuery));
				}

				var oFilter = null;
				if (aFilters.length) {
					oFilter = new sap.ui.model.Filter(aFilters, true);
				}

				// Binding filters to table
				var oTable = this.byId("triggerNWTable");
				oTable.getBinding("rows").filter(oFilter, "Application");
			},

			/**
			 * Handles the Press Event of the list items in the grouping select menu
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.TriggerNWCalls
			 */
			handleGroupingSelect: function(oEvent) {
				// Fetching the query from the drop-down
				var sSelected = oEvent.getSource().getSelectedItem().getId();
				var oSorter = null;

				// Getting the sorter
				if (sSelected.endsWith("groupBySource")) {
					oSorter = new sap.ui.model.Sorter("Source/EntitySet", false, true);
				} else if (sSelected.endsWith("groupByMethod")) {
					oSorter = new sap.ui.model.Sorter("HTTPMethod", false, true);
				} else if (sSelected.endsWith("groupByStatus")) {
					oSorter = new sap.ui.model.Sorter("Status", false, true);
				}

				// Binding sorter to table
				var oTable = this.byId("triggerNWTable");
				oTable.getBinding("rows").sort(oSorter, "Application");
			},

			_createRequestParams: function(sContextPath) {
				var that = this;
				var oQueryModel = this.getComponent().getModel("QueryModel");
				var oQuery = oQueryModel.getProperty(sContextPath);
				var oRequestData = {};
				if (oQuery.HTTPMethod !== "GET" && oQuery.RequestData && oQuery.RequestData.Data) {
					oRequestData = oQuery.RequestData.Data;
					this.getView().getModel("TriggerCalls").setProperty("/ParamRead", false);
				} else if (oQuery.HTTPMethod === "GET") {
					var sSampleDataPath = decodeURIComponent(oQuery.SampleDataPath);
					var iQueriesIndex = sSampleDataPath.indexOf("?");
					if (iQueriesIndex !== -1) {
						var sQueriesPath = sSampleDataPath.substring(iQueriesIndex + 1, sSampleDataPath.length - 1);
						oRequestData = sQueriesPath.split("&");
					}
					this.getView().getModel("TriggerCalls").setProperty("/ParamRead", true);
				}

				var aRequestData = [];
				// Convert Object to Array of Objects
				$.each(oRequestData, function(sKey, sValue) {
					if (oQuery.HTTPMethod === "GET") {
						aRequestData.push({
							key: sValue,
							value: ""
						});
					} else {
						aRequestData.push({
							key: sKey,
							value: sValue
						});
					}
				});

				oQueryModel.setProperty(sContextPath + "/RequestData/DataArray", aRequestData);
				var oParametersList = sap.ui.core.Fragment.byId("networkConsole", "requestParamsList");
				oParametersList.bindItems({
					path: "QueryModel>" + sContextPath + "/RequestData/DataArray",
					template: that._oParameterListTemplate.clone()
				});
			},
			handleUpdateFinished: function(oEvent) {
				// var iTotalItems = oEvent.getParameter("total");
				// sap.ui.core.Fragment.byId("networkConsole", "parameterListTitle").setText("Request Parameters (" + iTotalItems + ")");
			},

			handleParameterEditPress: function(oEvent) {
				var oButton = oEvent.getSource();
				var oTriggerCallModel = this.getView().getModel("TriggerCalls");
				if (oButton.getPressed()) {
					oButton.setIcon("sap-icon://display");
					oTriggerCallModel.setProperty("/ParamEdit", true);
				} else {
					oButton.setIcon("sap-icon://edit");
					oTriggerCallModel.setProperty("/ParamEdit", false);
				}
			},

			handleParameterSavePress: function() {
				var sQueryPath = "/Queries/" + this._iCurrentSelectedIndex;
				var sCRUDPath = this.getComponent().getModel("QueryModel").getProperty(sQueryPath + "/CRUDModelPath");
				var sCRUDType = this.getComponent().getModel("QueryModel").getProperty(sQueryPath + "/HTTPMethod");
				if (sCRUDType !== "GET") {
					this.getComponent().getModelHelper().modifyQuery(sCRUDPath, sQueryPath, sCRUDType);
				}
			},
			_createRequestParamsEditForm: function(oContext) {
				var sContextPath = oContext.getPath();
				var sHTTPMethod = oContext.getObject().HTTPMethod;
				var oQueryModel = this.getComponent().getModel("QueryModel");
				var sCRUDPath = oQueryModel.getProperty(sContextPath + "/CRUDModelPath");
				var oMainModel = this.getComponent().getModel();
				var aProperties = oMainModel.getProperty(sCRUDPath).property;
				var oParametersEditForm = sap.ui.core.Fragment.byId("networkConsole", "requestParamsEditForm");
				oParametersEditForm.destroyContent();
				var oTriggerCallModel = this.getView().getModel("TriggerCalls");
				var bIsCURDValid = oMainModel.getProperty(sCRUDPath).Valid;
				oTriggerCallModel.setProperty("/Error", !bIsCURDValid);
				oTriggerCallModel.setProperty("/ParamRead", false);
				if (!aProperties) {
					return;
				}

				if (sHTTPMethod === "POST" || sHTTPMethod === "PUT") {
					var iStringEnd = sCRUDPath.indexOf("/RequestData");
					var sCRUDEntitySetPath = sCRUDPath.substring(0, iStringEnd);
					var sSelectedKeyPath = sCRUDEntitySetPath + "/PayloadType";
					this._oPayloadTypeCombo.setVisible(true);
					this._oPayloadTypeCombo.bindProperty("selectedKey", sSelectedKeyPath);
				} else {
					this._oPayloadTypeCombo.setVisible(false);
					// this._oPayloadTypeCombo.bindProperty("selectedKey", null);
				}
				for (var i = 0; i < aProperties.length; i++) {
					if (aProperties[i].complexType || (sHTTPMethod === "DELETE" && !aProperties[i].key)) {
						continue;
					}
					var sText = "";
					var oLabel = new sap.m.Label({});
					if (aProperties[i].key) {
						sText = aProperties[i].name + "-(k)";
						oLabel.setText(sText);
						oLabel.setTooltip(sText);
						oLabel.addStyleClass("oDataTrackerKeyProperty");

						if (sHTTPMethod !== "POST") {
							oLabel.setRequired(true);
						};
					} else if (aProperties[i].complexParent) {
						sText = aProperties[i].name + "-(C)";
						oLabel.setText(sText);
						oLabel.setTooltip(aProperties[i].name + "-(Complex Type)");
						oLabel.addStyleClass("oDataTrackerComplexProperty");
					} else {
						sText = aProperties[i].name;
						oLabel.setText(sText);
						oLabel.setTooltip(sText);
					}

					var iLength = aProperties[i].maxLength ? parseInt(aProperties[i].maxLength, 10) : 0;

					if (isNaN(iLength)) {
						iLength = 0;
					}

					var iPrecision = isNaN(aProperties[i].Precision) ? undefined : parseInt(aProperties[i].Precision, 10);
					var iScale = isNaN(aProperties[i].Scale) ? undefined : parseInt(aProperties[i].Scale, 10);

					var sValuePath = sCRUDPath + "/property/" + i + "/value";
					var sValueStatePath = sCRUDPath + "/property/" + i + "/ValueState";

					var oProperties = {
						MaxLength: iLength,
						Precision: iPrecision,
						Scale: iScale
					};

					var fnValueEventHandler = null;
					if (sHTTPMethod === "PUT") {
						// Event Handler in case of Update
						fnValueEventHandler = function(oEvent) {
							var oSource = oEvent.getSource();
							var oValueContext = oSource.getBindingContext("QueryModel");
							var oModel = oSource.getModel();
							var sPath = oValueContext.getProperty("CRUDModelPath");
							var value, iErrorCount = 0;

							if (typeof oSource.getValue === "function") {
								value = oSource.getValue();
							} else if (typeof oSource.getSelectedKey === "function") {
								value = oSource.getSelectedKey();
							}

							var aValueProperties = oModel.getProperty(sPath + "/property");
							var bDataEntered = false;
							for (var k = 0; k < aValueProperties.length; k++) {
								if (aValueProperties[k].value) {
									bDataEntered = true;
								}
							}

							for (var i = 0; i < aValueProperties.length; i++) {
								if ((aValueProperties[i].key && aValueProperties[i].value) || (aValueProperties[i].key && !bDataEntered)) {
									oModel.setProperty(sPath + "/property/" + i + "/ValueState", "None");
								} else if (aValueProperties[i].key && !(aValueProperties[i].value)) {
									aValueProperties[i].ValueState = "Error";
									oModel.setProperty(sPath + "/property/" + i + "/ValueState", "Error");
									iErrorCount++;
								}
							}

							if (iErrorCount === 0) {
								oModel.setProperty(sPath + "/Valid", true);
								oTriggerCallModel.setProperty("/Error", false);
							} else {
								oModel.setProperty(sPath + "/Valid", false);
								oTriggerCallModel.setProperty("/Error", true);
							}

							if (bDataEntered) {
								oModel.setProperty(sPath + "/DataEntered", true);
							} else {
								oModel.setProperty(sPath + "/DataEntered", false);
							}
						};
					}
					var oInput = CommonHelper.createControlForODataType(aProperties[i].type, sValuePath, oProperties, {}, sValueStatePath,
						fnValueEventHandler);
					oParametersEditForm.addContent(oLabel);
					oParametersEditForm.addContent(oInput);
				}

			}
		});
	});
})();