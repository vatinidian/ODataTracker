(function() {
	"use strict";
	sap.ui.define([
		"sap/cd/ODataTracker/controller/BaseController", "sap/ui/model/odata/v2/ODataModel", "sap/ui/model/json/JSONModel",
		"sap/cd/ODataTracker/util/CommonHelper"
	], function(BaseController, ODataModel, JSONModel, CommonHelper) {
		return BaseController.extend("sap.cd.ODataTracker.controller.MetadataConfig", {

			onInit: function() {
				this._oCopyContext = null;
				this._oCopyButton = null;

				this.getComponent().getModelHelper().registerForModelLoadedFromFile(function(bModelLoadedFromFile) {
					if (bModelLoadedFromFile) {
						// this.byId("metadataInput").setValue();
						this._createSchemaPanelWithTable();
					}
				}, this);

				// Attach Enter to input field
				var oInput = this.byId("metadataInput");
				CommonHelper.attachEnterToField(oInput, this.handleMetadataLoading, this);
			},

			handleRelativeCheckBoxSelect: function(oEvent) {
				var oCheckBox = oEvent.getSource();
				var oModel = this.getComponent().getModel();
				var sRootUrl = window.location.origin;
				var sServiceUrl = oModel.getProperty("/ServiceUrl");
				var sRegExp = new RegExp('^(?:[a-z]+:)?//', 'i');
				var bAbsoluteUrl = sRegExp.test(sServiceUrl);

				// Checking if Relative URL Check Box is selected
				if (oCheckBox.getSelected()) {
					if (!bAbsoluteUrl) {
						// Checking if the entered URL isn't an absolute URL
						if (sServiceUrl.indexOf("/") != 0) {
							// Append "/" to the beginning of the relative URL if it doesn't exist
							sServiceUrl = "/" + sServiceUrl;
						}
						// Add the Root URL to the Service URL
						sServiceUrl = sRootUrl + sServiceUrl;
						oModel.setProperty("/ServiceUrl", sServiceUrl);
					} else {
						// If the entered URL is an absolute URL, show a Message Toast
						sap.m.MessageToast.show(sServiceUrl + " isn't a relative URL");
					}
				}
			},

			/**
			 * 
			 * 
			 */
			/*	handleRelativeCheckBoxSelect: function(oEvent) {
					var oCheckBox = oEvent.getSource();
					var oModel = this.getComponent().getModel();
					var sRootUrl = window.location.origin;
					var sServiceUrl = oModel.getProperty("/ServiceUrl");

					// If Relative URL Check Box is selected
					if (oCheckBox.getSelected()) {
						if ((sServiceUrl.indexOf("http://") != 0) && (sServiceUrl.indexOf("https://") != 0)) {
							// If the entered URL isn't an absolute URL
							if (sServiceUrl.indexOf("/") != 0) {
								// Append "/" to the beginning of the relative URL if it doesn't exist
								sServiceUrl = "/" + sServiceUrl;
							}
							// Add the Root URL to the Service URL
							sServiceUrl = sRootUrl + sServiceUrl;
							oModel.setProperty("/ServiceUrl", sServiceUrl);
						} else {
							// If the entered URL is an absolute URL, show a Message Toast
							sap.m.MessageToast.show(sServiceUrl + " isn't a relative URL");
						}
					}
				},*/
			/**
			 * 
			 * 
			 */
			handleMetadataLoading: function() {
				var oInput = this.byId("metadataInput");
				var sValue = oInput.getValue().trim();

				// Adding an "/" to the end of the URL in case it doesn't exist
				if (!((sValue.lastIndexOf("/") + 1) == sValue.length)) {
					sValue = sValue + "/";
					oInput.setValue(sValue);
				}

				if (!sValue) {
					return;
				}
				this.getView().setBusy(true);
				this.getView().setBusyIndicatorDelay(0);

				this.getComponent().getNavigationHelper().resetNavTabsToInitialState();
				var oController = this;

				this.getComponent().getModelHelper()._createModel(sValue, {
					success: function(oDataModel) {
						// TODO : Check
						var oServiceMetadata = oDataModel.getServiceMetadata();
						var oDataServices = oServiceMetadata.dataServices;

						if (!$.isEmptyObject(oDataServices)) {
							var oModel = oController.getComponent().getModel();
							oModel.setProperty("/schema", oDataServices.schema);
							oController.getComponent().getModelHelper().enhanceModelToAddCRUDObject();
							oModel.setProperty("/ModelChanged", true);
							//
							oController.getComponent().getModelHelper().enhanceModelAddEntityTypeToEntitySetObject();

							oController._createSchemaPanelWithTable();
						}

						oController.getView().setBusy(false);
					},

					error: function(oError) {
						var oContainer = oController.byId("metadataSchemaContainer");
						oContainer.destroyContent();
						oContainer.setVisible(false);

						var oErrorMsgStrip = oController.byId("metadataFailedMsgStrip");
						oErrorMsgStrip.setVisible(true);

						var sMessage = oError.getParameter("message");
						var oResponse = oError.getParameter("response");
						var sResponseText = oResponse.responseText ? oResponse.responseText : oResponse.body;
						oErrorMsgStrip.setText(sMessage + "\n\nStatus Code : " + oResponse.statusCode + "\n\nStatus Text : " + oResponse.statusText +
							"\n\nResponse Text : " + sResponseText);

						oController.getView().setBusy(false);
						oController.getComponent().getNavigationHelper().disableNextSteps("MetadataConfig");
					}
				});
			},
			/**
			 * 
			 */
			_createSchemaPanelWithTable: function() {
				var oController = this;
				var oContainer = this.byId("metadataSchemaContainer");
				oContainer.destroyContent();
				oContainer.setVisible(true);

				var oErrorMsgStrip = this.byId("metadataFailedMsgStrip");
				oErrorMsgStrip.setVisible(false);

				var oModel = this.getComponent().getModel();
				var aSchema = oModel.getProperty("/schema");

				if (aSchema.length > 0) {
					for (var i = 0; i < aSchema.length; i++) {

						if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {
							// Enhance the existing main Model for CRUD
							// TODO : Check :Consider only one EntityContainer ?

							var sId = aSchema[i].namespace.replace(/[^a-zA-Z_]/g, "_");
							var oSchemaPanel = sap.ui.xmlfragment(sId, "sap.cd.ODataTracker.view.fragment.SchemaPanel", this);
							oSchemaPanel.setHeaderText("Schema : " + aSchema[i].namespace);

							this.getView().addDependent(oSchemaPanel);

							var oTable = sap.ui.core.Fragment.byId(sId, "EntitySetTable");
							oTable.bindRows("/schema/" + i + "/entityContainer/0/entitySet");
							// Set Visible row Counts
							var iLength = oTable.getBinding("rows").getLength();
							if (iLength > oTable.getVisibleRowCount() && iLength <= 10) {
								oTable.setVisibleRowCount(iLength);
							} else if (iLength > 10) {
								oTable.setVisibleRowCount(10);
							}

							sap.ui.core.Fragment.byId(sId, "EntitySetTableTitle").setText("EntitySets (" + iLength + ")");

							// Create List for Function Imports
							if (aSchema[i].entityContainer[0].functionImport && aSchema[i].entityContainer[0].functionImport.length > 0) {
								var oFnImportList = new sap.m.List(sId + "__FunctionImportList", {
									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title(this.createId("FunctionImportListTitle"), {
												text: "Function Import List"
											}), new sap.m.ToolbarSpacer({}), new sap.m.SearchField({
												placeholder: "Search Function Import",
												width: "25rem",
												search: function(oEvent) {
													// Search for Function Imports
													var sQuery = oEvent ? oEvent.getParameter("query") : "";
													var oFilter = null;

													if (sQuery) {
														oFilter = new sap.ui.model.Filter([
															new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sQuery), new sap.ui.model.Filter(
																"functionImport", sap.ui.model.FilterOperator.Contains, sQuery)
														], false);
													}
													oFnImportList.getBinding("items").filter(oFilter, "Application");
												}
											})
										]
									}),
									growing: true,
									growingThreshold: 10,
									items: {
										path: '/schema/' + i + '/entityContainer/0/functionImport',
										template: new sap.m.StandardListItem({
											title: "Name : {name}",
											info: "Return Type : {returnType}",
											type: "Navigation",
											description: "Http Method : {httpMethod}"
										})
									},
									itemPress: $.proxy(this.handleConfigureEntitySet, this),
									updateFinished: function() {
										// Showing the number of items in the list
										var iLength = oFnImportList.getBinding("items").getLength();
										oController.byId("FunctionImportListTitle").setText("Function Imports (" + iLength + ")");
									}
								}).addStyleClass("oDataTrackerMetaConfigListHeader");
								oSchemaPanel.addContent(oFnImportList);
							}

							// Create List for Association Sets
							if (aSchema[i].entityContainer[0].associationSet && aSchema[i].entityContainer[0].associationSet.length > 0) {

								var oAssociationSetList = new sap.m.List(sId + "__AssociationList", {
									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title(this.createId("AssociationListTitle"), {
												text: "Association Set"
											}), new sap.m.ToolbarSpacer({}), new sap.m.SearchField({
												placeholder: "Search Association Set",
												width: "25rem",
												search: function(oEvent) {
													// Search for Association Sets
													var sQuery = oEvent ? oEvent.getParameter("query") : "";
													var oFilter = null;

													if (sQuery) {
														oFilter = new sap.ui.model.Filter([
															new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sQuery), new sap.ui.model.Filter(
																"associationSet", sap.ui.model.FilterOperator.Contains, sQuery)
														], false);
													}
													oAssociationSetList.getBinding("items").filter(oFilter, "Application");
												}
											})
										]
									}),
									growing: true,
									growingThreshold: 10,
									items: {
										path: '/schema/' + i + '/entityContainer/0/associationSet',
										template: new sap.m.StandardListItem({
											title: "Name : {name}",
											info: "Association : {association}"
										})
									},
									updateFinished: function() {
										// Showing the number of items in the list
										var iLength = oAssociationSetList.getBinding("items").getLength();
										oController.byId("AssociationListTitle").setText("Association Sets (" + iLength + ")");
									}
								}).addStyleClass("oDataTrackerMetaConfigListHeader");
								oSchemaPanel.addContent(oAssociationSetList);
							}

							// Create List for Complex Types
							if (aSchema[i].complexType && aSchema[i].complexType.length > 0) {

								var oComplexTypeList = new sap.m.List(sId + "__ComplexTypeList", {
									headerToolbar: new sap.m.Toolbar({
										content: [
											new sap.m.Title(this.createId("ComplexTypeListTitle"), {
												text: "Complex Type"
											}), new sap.m.ToolbarSpacer({}), new sap.m.SearchField({
												placeholder: "Search Complex Type",
												width: "25rem",
												search: function(oEvent) {
													// Search for Association Sets
													var sQuery = oEvent ? oEvent.getParameter("query") : "";
													var oFilter = null;

													if (sQuery) {
														oFilter = new sap.ui.model.Filter([
															new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sQuery), new sap.ui.model.Filter(
																"complexType", sap.ui.model.FilterOperator.Contains, sQuery)
														], false);
													}
													oComplexTypeList.getBinding("items").filter(oFilter, "Application");
												}
											})
										]
									}),
									growing: true,
									growingThreshold: 10,
									items: {
										path: '/schema/' + i + '/complexType',
										template: new sap.m.StandardListItem({
											title: "Name : {name}"
										})
									},
									updateFinished: function() {
										// Showing the number of items in the list
										var iLength = oComplexTypeList.getBinding("items").getLength();
										oController.byId("ComplexTypeListTitle").setText("Complex Type (" + iLength + ")");
									}
								}).addStyleClass("oDataTrackerMetaConfigListHeader");
								oSchemaPanel.addContent(oComplexTypeList);
							}

							oContainer.addContent(oSchemaPanel);
						} else {
							// TODO : handle if schema has only FunctionImports / Association sets
						}
					}

					// Enable Next Step Navigation Tab
					this.getComponent().getNavigationHelper().enableNextStep("MetadataConfig");
				} else {
					// TODO : Implement
					// Display message
				}
			},

			handleCopyEntitySets: function(oEvent) {
				var oButton = oEvent.getSource();
				this._oCopyButton = oButton;

				// Find Corresponding Table for this Button
				var oTable = this._fnGiveTableRef(oButton.getParent());
				var iIndex = oTable.getSelectedIndex();
				var oContext = null;
				if (iIndex >= 0) {
					oContext = oTable.getContextByIndex(iIndex);
					this._oCopyContext = oContext;
					oTable.setSelectionMode(sap.ui.table.SelectionMode.MultiToggle);
					oTable.setSelectionBehavior(sap.ui.table.SelectionBehavior.RowSelector);

					oTable.setSelectedIndex(iIndex);

					oButton.setEnabled(false);
				} else {
					this._oCopyContext = null;
					sap.m.MessageToast.show("Please Select a Row");
				}
			},

			handlePaste: function(oEvent) {
				var oButton = oEvent.getSource();
				// Find Corresponding Table for this Button
				var oTable = this._fnGiveTableRef(oButton);
				var aIndices = oTable.getSelectedIndices();

				if (aIndices.length < 2) {
					sap.m.MessageToast.show("Please select some rows to paste");
					return;
				}

				var oContext = null;
				var oModel = this.getComponent().getModel();
				for (var i = 0; i < aIndices.length; i++) {
					oContext = oTable.getContextByIndex(aIndices[i]);
					if (oContext !== this._oCopyContext) {
						oModel.setProperty(oContext.getPath() + "/crud/Create/Available", this._oCopyContext.getProperty("crud/Create/Available"));
						oModel.setProperty(oContext.getPath() + "/crud/Read/Available", this._oCopyContext.getProperty("crud/Read/Available"));
						oModel.setProperty(oContext.getPath() + "/crud/Update/Available", this._oCopyContext.getProperty("crud/Update/Available"));
						oModel.setProperty(oContext.getPath() + "/crud/Delete/Available", this._oCopyContext.getProperty("crud/Delete/Available"));
					}
				}

				oTable.setSelectionMode(sap.ui.table.SelectionMode.Single);
				oTable.clearSelection();
				sap.m.MessageToast.show("Rows Copied");

				this._oCopyContext = null;
				this._oCopyButton.setEnabled(true);
				this._oCopyButton = null;
			},

			handleTableActionsCancel: function(oEvent) {
				var oButton = oEvent.getSource();
				// Find Corresponding Table for this Button
				var oTable = this._fnGiveTableRef(oButton);
				oTable.setSelectionMode(sap.ui.table.SelectionMode.Single);
				oTable.clearSelection();

				this._oCopyContext = null;
				this._oCopyButton ? this._oCopyButton.setEnabled(true) : "";
				this._oCopyButton = null;
			},

			_fnGiveTableRef: function(oControl) {
				if (oControl instanceof sap.ui.table.Table) {
					return oControl;
				} else {
					return oControl.getParent() ? this._fnGiveTableRef(oControl.getParent()) : null;
				}
			},

			handleEntitySetSearch: function(oEvent) {
				var sQuery = oEvent ? oEvent.getParameter("query") : "";
				var oFilter = null;

				if (sQuery) {
					oFilter = new sap.ui.model.Filter([
						new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sQuery), new sap.ui.model.Filter("entityType", sap.ui.model
							.FilterOperator.Contains, sQuery)
					], false);
				}

				var oTable = this._fnGiveTableRef(oEvent.getSource());
				oTable.getBinding("rows").filter(oFilter, "Application");

				// Set Visible row Counts
				var iLength = oTable.getBinding("rows").getLength();

				if (iLength > 10) {
					oTable.setVisibleRowCount(10);
				} else {
					oTable.setVisibleRowCount(iLength);
				}
			},

			handleRejectCRUDStateChange: function(oEvent) {
				var oSource = oEvent.getSource();
				var oContext = oSource.getBindingContext();
				var sPath = oContext.getPath();

				// Update all Available CRUD property to false
				var oModel = oContext.getModel();
				oModel.setProperty(sPath + "/crud/Create/Available", !oSource.getState());
				oModel.setProperty(sPath + "/crud/Update/Available", !oSource.getState());
				oModel.setProperty(sPath + "/crud/Read/Available", !oSource.getState());
				oModel.setProperty(sPath + "/crud/Delete/Available", !oSource.getState());
			},

			handleCRUDStateChange: function(oEvent) {
				var oSource = oEvent.getSource();
				var oContext = oSource.getBindingContext();
				var sPath = oContext.getPath();

				var oModel = oContext.getModel();
				var bCreate = oModel.getProperty(sPath + "/crud/Create/Available");
				var bUpdate = oModel.getProperty(sPath + "/crud/Update/Available");
				var bRead = oModel.getProperty(sPath + "/crud/Read/Available");
				var bDelete = oModel.getProperty(sPath + "/crud/Delete/Available");

				if (bCreate || bUpdate || bRead || bDelete) {
					oModel.setProperty(sPath + "/crud/Reject", false);
				} else {
					oModel.setProperty(sPath + "/crud/Reject", true);
				}
			},

			handleConfigureEntitySet: function(oEvent) {
				var oSource = oEvent.getSource();
				var oContext = oSource.getBindingContext();

				var sType = "EntitySet";
				if (!oContext && oSource instanceof sap.m.List) {
					oContext = oEvent.getParameter("listItem").getBindingContext();
					sType = "FunctionImport";
				}

				var sPath = oContext.getPath();

				var oView = this._fnGiveViewRef(oSource.getParent());
				var oControl = oView.byId("navigationContainer");
				var aButtons = oControl.getContent();
				var oModel = oContext.getModel();

				for (var i = 0; i < aButtons.length; i++) {
					if (aButtons[i].data("TabName") === "SampleDataConfig") {

						var sTabName = aButtons[i].data("TabName");
						var sTargetRoute = aButtons[i].data("TargetRoute");

						if (oModel.getProperty("/CurrentScreen/TabName") === sTabName) {
							return;
						}

						// Change Tab Style
						this.getComponent().getNavigationHelper()._changeNavigationButtonTabStates(aButtons[i]);

						oModel.setProperty("/CurrentScreen/Name", this.getComponent().getNavigationHelper().TargetsScreenName[sTabName]);
						oModel.setProperty("/CurrentScreen/RouteName", sTargetRoute);
						oModel.setProperty("/CurrentScreen/TabName", sTabName);

						this.getRouter().getTargets().display("SampleDataConfig", {
							type: sType,
							contextPath: sPath
						});

						return;
					}
				}
			},

			_fnGiveViewRef: function(oControl) {
				if (oControl instanceof sap.ui.core.mvc.View && oControl.data("ViewName") === "MainView") {
					return oControl;
				} else {
					return oControl.getParent() ? this._fnGiveViewRef(oControl.getParent()) : null;
				}
			},

			onExit: function() {
				// Detach Enter to input field
				var oInput = this.byId("metadataInput");
				CommonHelper.detachEnterFromField(oInput);
			}
		});
	});
})();