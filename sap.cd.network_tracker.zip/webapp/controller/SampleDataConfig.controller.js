(function() {
	"use strict";
	sap.ui.define([
		"sap/cd/ODataTracker/controller/BaseController", "sap/ui/model/odata/v2/ODataModel", "sap/ui/model/json/JSONModel"
	], function(BaseController, ODataModel, JSONModel) {
		return BaseController.extend("sap.cd.ODataTracker.controller.SampleDataConfig", {
			onInit: function() {
				/* Start of Private member initialization */
				this._sCurrentSchema = "";
				this._iCurrentSchemaCount = 0;
				this._iValidSchemaCount = 0;
				this._aDefaultFilters = [];
				// TODO : move this to Model
				this.aDataTypes = [
					"Edm.GeographyPoint", "Edm.String", "Edm.Int", "Edm.Int16", "Edm.Int32", "Edm.Int64", "Edm.Binary", "Edm.Boolean", "Edm.Byte", "Edm.SByte", "Edm.DateTime", "Edm.Decimal", "Edm.Double", "Edm.Single", "Edm.Guid", "Edm.Time", null
				];
				/* End of Private member initialization */

				this.getComponent().getModelHelper().registerForModelChange(function(bModelChanged) {
					if (bModelChanged) {
						// Reset all values
						this._sCurrentSchema = "";
						this._iCurrentSchemaCount = 0;
						this._iValidSchemaCount = 0;
						this._aDefaultFilters = [];

						var oModel = this.getComponent().getModel();
						oModel.setProperty("/ModelChanged", false);
					}
				}, this);

				var oRouter = this.getRouter();
				oRouter.getTargets().attachDisplay(null, this._onRouteMatched, this);
			},

			/**
			 * 
			 */
			_onRouteMatched: function(oEvent) {
				if (oEvent.getParameter("name") !== "SampleDataConfig") {
					return;
				}

				var oMasterPage = this.byId("SampleDataMasterPage");
				oMasterPage.setShowSubHeader(false);

				var aLayoutContents = this.byId("filterLayout").getContent();
				for (var i = 0; i < aLayoutContents.length; i++) {
					if (aLayoutContents[i] instanceof sap.m.CheckBox) {
						aLayoutContents[i].setSelected(false);
					}
				}

				this.byId("fnImportButton").setPressed(false);
				this.byId("filterButton").setPressed(false);
				this._aDefaultFilters = [];
				this.byId("sampleDataDetailContent").destroyContent();

				//
				this._iValidSchemaCount = 0;
				var oModel = this.getComponent().getModel();
				var aSchema = oModel.getProperty("/schema");

				for (var i = 0; i < aSchema.length; i++) {
					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {
						this._iValidSchemaCount++;
					}
				}

				//
				this._iCurrentSchemaCount = 0;
				this._schemaNavigation();

				// Create List
				if (oEvent.getParameter("data") && oEvent.getParameter("data").contextPath && oEvent.getParameter("data").type) {
					this._createMasterPageList(oEvent.getParameter("data").type, oEvent.getParameter("data").contextPath);
				} else {
					this._createMasterPageList();
				}

				// Bind Items to list
				this._bindItemsToMasterList();

				// Enable Next Step -: Trigger Network Calls
				this.getComponent().getNavigationHelper().enableNextStep("SampleDataConfig");

				// Erase the query in the Search Bar in Master Page
				this.byId("searchField").setValue("");
				this.byId("searchField").setVisible(false);
				this.byId("searchButton").setVisible(true);
			},

			/**
			 * Makes the Search Field visible and hides the Search Button
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleSearchButtonPress: function() {
				this.byId("searchField").setVisible(true);
				this.byId("searchButton").setVisible(false);
				jQuery.sap.delayedCall(0, this, function() {
					this.byId("searchField").focus();
				});
			},

			/**
			 * Searches for Entity Sets and Function Imports in their respective Lists
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleSearch: function(oEvent) {
				var oEntitySetList = this.byId("sampleDataMasterList");
				var oFnImportList = this.byId("sampleDataMasterFnImportList");

				var sQuery = oEvent ? oEvent.getParameter("query") : "";
				var oFilter = null;

				if (sQuery) {
					// Filter for Entity Sets and Function Imports
					oFilter = new sap.ui.model.Filter([
						new sap.ui.model.Filter("name", sap.ui.model.FilterOperator.Contains, sQuery)
					], false);
				}

				oEntitySetList.getBinding("items").filter(oFilter, "Application");
				oFnImportList.getBinding("items").filter(oFilter, "Application");

				// If the Search Field is cleared, hide the Search Field and show the Search Button
				if (!sQuery) {
					this.byId("searchField").setVisible(false);
					this.byId("searchButton").setVisible(true);
				}
			},

			/**
			 * Handles the Press Event of a List Item of the Entity Sets List
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleListItemPressed: function(oEvent) {
				this.byId("sampleDataMasterFnImportList").removeSelections();
				this.byId("CRUDOperationChangeLayout").setVisible(true);

				var oDetailPage = this.byId("sampleDataDetailPage");
				var oContext = oEvent.getSource().getSelectedItem().getBindingContext();
				oDetailPage.setBindingContext(oContext);

				this._createDetailPage();
			},

			/**
			 * 
			 */
			_createMasterPageList: function(sType, sContextPath) {
				var oController = this;
				var oMasterPage = this.byId("SampleDataMasterPage");
				oMasterPage.destroyContent();

				var oList = new sap.m.List(this.createId("sampleDataMasterList"), {
					mode: "SingleSelectMaster",
					itemPress: $.proxy(this.handleListItemPressed, this),
					infoToolbar: new sap.m.Toolbar({
						active: false,
						content: [
							new sap.m.Label(this.createId("entitySetsLabel"), {
								text: "Entity Sets"
							})
						]
					})
				});

				oList.attachUpdateFinished(function() {
					// Fire first item
					var iCount = oList.getBinding("items").getLength();
					var oFirstItem = oList.getItems()[0];

					// Showing the number of items in the list
					this.byId("entitySetsLabel").setText("Entity Sets (" + iCount + ")");

					if (iCount === 0) {
						// TODO : Show message
						this.byId("sampleDataDetailContent").destroyContent();
						this.byId("sampleDataDetailPage").setBindingContext(null);
						this.byId("CRUDOperationChangeLayout").setVisible(false);
					} else {
						this.byId("CRUDOperationChangeLayout").setVisible(true);
						if (oFirstItem && (!sContextPath && (sType !== "EntitySet" || sType !== "FunctionImport"))) {
							oList.setSelectedItem(oFirstItem);
							oList.fireItemPress();
						}
					}

					if (sType && sType === "EntitySet") {
						var aItems = oList.getItems();
						for (var i = 0; i < aItems.length; i++) {
							if (aItems[i].getBindingContext().getPath() === sContextPath) {
								oList.setSelectedItem(aItems[i]);
								oList.fireItemPress();
							}
						}
					}
				}, this);

				var oListForFnImport = new sap.m.List(this.createId("sampleDataMasterFnImportList"), {
					mode: "SingleSelectMaster",
					itemPress: $.proxy(this.handleFnImportListItemPressed, this),
					infoToolbar: new sap.m.Toolbar({
						active: false,
						content: [
							new sap.m.Label(this.createId("functionImportsLabel"), {
								text: "Function Imports"
							})
						]
					}),
					updateFinished: function() {
						// Showing the number of items in the list
						var iLength = oListForFnImport.getBinding("items").getLength();
						oController.byId("functionImportsLabel").setText("Function Imports (" + iLength + ")");

						// Showing the first item in the Detail Page in case there are no items in Entity Sets List
						if (!oController.byId("sampleDataMasterList").getItems().length && (!sContextPath && (sType !== "EntitySet" || sType !== "FunctionImport"))) {
							oListForFnImport.setSelectedItem(oListForFnImport.getItems()[0]);
							oListForFnImport.fireItemPress();
						}

						if (sType && sType === "FunctionImport") {
							var aItems = oListForFnImport.getItems();
							for (var i = 0; i < aItems.length; i++) {
								if (aItems[i].getBindingContext().getPath() === sContextPath) {
									oListForFnImport.setSelectedItem(aItems[i]);
									oListForFnImport.fireItemPress();

									// TODO : Remove below code once scroll bar adjustment has been done
									// oController.byId("fnImportButton").firePress();
								}
							}
						}
					}
				});

				oMasterPage.addContent(oList);
				oMasterPage.addContent(oListForFnImport);
			},

			/**
			 * 
			 */
			_schemaNavigation: function() {
				var oModel = this.getComponent().getModel();
				var aSchema = oModel.getProperty("/schema");

				if (aSchema.length <= 1 || this._iValidSchemaCount <= 1) {
					return;
				}

				if (this._iCurrentSchemaCount > 0) {
					this.byId("previousSchemaBtn").setEnabled(true);
				} else {
					this.byId("previousSchemaBtn").setEnabled(false);
				}

				if (this._iCurrentSchemaCount === aSchema.length) {
					this.byId("nextSchemaBtn").setEnabled(false);
				} else {
					this.byId("nextSchemaBtn").setEnabled(true);
				}
			},

			/**
			 * 
			 */
			handleFunctionImportShowButtonPress: function(oEvent) {

				var oButton = oEvent.getSource();
				// Scroll to Function Import List
				var oFunctionImportList = this.byId("sampleDataMasterFnImportList");

				if (oFunctionImportList) {
					var iScrollHeight = oFunctionImportList.getDomRef().offsetTop;
					// Get the MasterPage reference
					var oMasterPage = this.byId("SampleDataMasterPage");

					if (oButton.getPressed()) {
						oMasterPage.getDomRef().getElementsByTagName("section")[0].scrollTop = iScrollHeight;
					} else {
						oMasterPage.getDomRef().getElementsByTagName("section")[0].scrollTop = 0;
					}

				}
			},

			/**
			 * 
			 */
			handleShowNextSchema: function() {
				this._bindItemsToMasterList(true);
				this._schemaNavigation();
			},

			/**
			 * 
			 */
			handleShowPreviousSchema: function() {
				this._bindItemsToMasterList(false, true);
				this._schemaNavigation();
			},

			/**
			 * 
			 */
			_bindItemsToMasterList: function(bShowNext, bShowPrevious) {
				var sPath = "";
				var oModel = this.getComponent().getModel();
				var aSchema = oModel.getProperty("/schema");
				var bSetNextPathToList = false;
				var bSetPreviousPathToList = false;

				// Binding Entity Sets
				var oList = this.byId("sampleDataMasterList");

				for (var i = 0; i < aSchema.length; i++) {
					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {

						if (bSetNextPathToList || (!bShowNext && !bShowPrevious)) {
							sPath = "/schema/" + i + "/entityContainer/0/entitySet";
							this.byId("matserPageTitle").setText("Schema : " + aSchema[i].namespace);
							this._sCurrentSchema = aSchema[i].namespace;

							if (bShowNext) {
								this._iCurrentSchemaCount = this._iCurrentSchemaCount + 1;
							}
							break;
						}

						if (bSetPreviousPathToList && bShowPrevious) {
							sPath = "/schema/" + i + "/entityContainer/0/entitySet";
							this.byId("matserPageTitle").setText("Schema : " + aSchema[i].namespace);
							this._sCurrentSchema = aSchema[i].namespace;
							this._iCurrentSchemaCount = this._iCurrentSchemaCount - 1;
							break;
						}

						if (this._sCurrentSchema === aSchema[i].namespace && bShowNext) {
							bSetNextPathToList = true;
						}

						if (i > 0 && this._sCurrentSchema === aSchema[i].namespace && bShowPrevious) {
							bSetPreviousPathToList = true;
							i--;
						}
					} else {
						if (bSetPreviousPathToList) {
							sap.m.MessageToast.show("There is no previous schema");
						}
					}
				}

				if (!sPath) {
					sap.m.MessageToast.show("Schema Not available");
					return;
				}
				var oCreateFilter = new sap.ui.model.Filter("crud/Create/Available", "EQ", true);
				var oReadFilter = new sap.ui.model.Filter("crud/Read/Available", "EQ", true);
				var oUpdateFilter = new sap.ui.model.Filter("crud/Update/Available", "EQ", true);
				var oDeleteFilter = new sap.ui.model.Filter("crud/Delete/Available", "EQ", true);
				var aFilters = new sap.ui.model.Filter([
					oCreateFilter, oReadFilter, oUpdateFilter, oDeleteFilter
				], false);

				this._aDefaultFilters = aFilters;

				var oItem = new sap.m.StandardListItem({
					title: "{name}",
					type: "Active",
					description: "E : {entityType}",
					info: {
						parts: [
							'crud/Create/Available', 'crud/Read/Available', 'crud/Update/Available', 'crud/Delete/Available'
						],
						formatter: function(bCreate, bRead, bUpdate, bDelete) {
							var sCRUD = "";

							if (bCreate) {
								sCRUD = sCRUD + "C";
							}

							if (bRead) {
								sCRUD = sCRUD + "R";
							}

							if (bUpdate) {
								sCRUD = sCRUD + "U";
							}

							if (bDelete) {
								sCRUD = sCRUD + "D";
							}

							return sCRUD;
						}
					}
				});

				// Bind only first schema
				oList.bindItems({
					path: sPath,
					template: oItem.clone(),
					filters: aFilters
				});

				// Binding Function Imports
				var oFnImportList = this.byId("sampleDataMasterFnImportList");

				for (var i = 0; i < aSchema.length; i++) {
					if (aSchema[i].entityContainer && aSchema[i].entityContainer.length > 0) {

						if (bSetNextPathToList || (!bShowNext && !bShowPrevious)) {
							sPath = "/schema/" + i + "/entityContainer/0/functionImport";
							this._sCurrentSchema = aSchema[i].namespace;

							if (bShowNext) {
								this._iCurrentSchemaCount = this._iCurrentSchemaCount + 1;
							}
							break;
						}

						if (bSetPreviousPathToList && bShowPrevious) {
							sPath = "/schema/" + i + "/entityContainer/0/functionImport";
							this._sCurrentSchema = aSchema[i].namespace;
							this._iCurrentSchemaCount = this._iCurrentSchemaCount - 1;
							break;
						}

						if (this._sCurrentSchema === aSchema[i].namespace && bShowNext) {
							bSetNextPathToList = true;
						}

						if (i > 0 && this._sCurrentSchema === aSchema[i].namespace && bShowPrevious) {
							bSetPreviousPathToList = true;
							i--;
						}
					} else {
						if (bSetPreviousPathToList) {
							sap.m.MessageToast.show("There is no previous schema");
						}
					}
				}

				if (!sPath) {
					sap.m.MessageToast.show("Schema Not available");
					return;
				}

				var oItem = new sap.m.StandardListItem({
					title: "{name}",
					type: "Active",
					description: "{returnType}",
					info: "{httpMethod}"
				});

				// Bind only first schema
				oFnImportList.bindItems({
					path: sPath,
					template: oItem.clone()
				});
			},

			/**
			 * 
			 */
			handleFilterButtonPress: function(oEvent) {
				var oButton = oEvent.getSource();
				var oMasterPage = this.byId("SampleDataMasterPage");

				if (oButton.getPressed()) {
					oMasterPage.setShowSubHeader(true);
				} else {
					oMasterPage.setShowSubHeader(false);
				}
			},

			/**
			 * 
			 */
			handleFilterSelect: function(oEvent) {
				var oCheckBox = oEvent.getSource();
				var sFilterkey = oCheckBox.data("FilterKey");
				var oList = this.byId("sampleDataMasterList");
				var aLayoutContents = this.byId("filterLayout").getContent();
				var oBinding = oList.getBinding("items");
				var bApplyFilters = false;

				var oCreateFilter, oReadFilter, oUpdateFilter, oDeleteFilter, aFilters = [], aInnnerFilters = [];

				for (var i = 0; i < aLayoutContents.length; i++) {
					if (!aLayoutContents[i] instanceof sap.m.CheckBox) {
						continue;
					}

					if (aLayoutContents[0].getSelected() && aLayoutContents[i] !== oCheckBox) {
						aLayoutContents[i].setSelected(!aLayoutContents[0].getSelected());
					} else if (oCheckBox !== aLayoutContents[0] && aLayoutContents[i] !== oCheckBox) {
						aLayoutContents[0].setSelected(false);
					}

					if (aLayoutContents[i].getSelected()) {
						bApplyFilters = true;
					}

					if (aLayoutContents[i].data('FilterKey') !== "REJECTED" && sFilterkey !== "REJECTED") {
						aInnnerFilters.push(new sap.ui.model.Filter("crud/" + aLayoutContents[i].data('FilterKey') + "/Available", "EQ", aLayoutContents[i].getSelected()));
					}

				}

				if (sFilterkey === "REJECTED") {
					oCreateFilter = new sap.ui.model.Filter("crud/Create/Available", "EQ", !oCheckBox.getSelected());
					oReadFilter = new sap.ui.model.Filter("crud/Read/Available", "EQ", !oCheckBox.getSelected());
					oUpdateFilter = new sap.ui.model.Filter("crud/Update/Available", "EQ", !oCheckBox.getSelected());
					oDeleteFilter = new sap.ui.model.Filter("crud/Delete/Available", "EQ", !oCheckBox.getSelected());
					aFilters = new sap.ui.model.Filter([
						oCreateFilter, oReadFilter, oUpdateFilter, oDeleteFilter
					], true);
					bApplyFilters = true;
				} else {
					aFilters.push(new sap.ui.model.Filter(aInnnerFilters, true));
				}

				oBinding.filter(bApplyFilters ? aFilters : []);
			},

			/**
			 * 
			 */
			_createDetailPageCRUDPanel: function(sCRUDOperation) {
				var bCreate = false, bRead = false, bUpdate = false, bDelete = false;
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				var oPanel = this.byId(sCRUDOperation + "_Panel");
				if (oPanel) {
					return oPanel;
				}

				var oPayloadTypeCombo = null;

				// TODO : Use Enum
				switch (sCRUDOperation) {
					case "Create":
						bCreate = true;
						break;
					case "Read":
						bRead = true;
						break;
					case "Update":
						bUpdate = true;
						break;
					case "Delete":
						bDelete = true;
						break;
				}
				;

				if (bCreate || bUpdate) {
					oPayloadTypeCombo = new sap.m.ComboBox({
						selectedKey: "{" + sContextPath + "/crud/" + sCRUDOperation + "/PayloadType}",
						items: [
							new sap.ui.core.Item({
								key: "01",
								text: "Payload - Send Selected"
							}), new sap.ui.core.Item({
								key: "02",
								text: "Payload - Send All"
							})
						]
					});
				}
				oPanel = new sap.m.Panel(this.createId(sCRUDOperation + "_Panel"), {
					expandable: true,
					expanded: true,
					width: "auto",
					visible: {
						path: sContextPath + "/crud/" + sCRUDOperation + "/Available",
						formatter: function(bCRUD) {
							if (bCRUD) {
								return true;
							} else {
								return false;
							}
						}
					},
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Text({
								text: sCRUDOperation
							}),

							new sap.m.ToolbarSpacer(),

							oPayloadTypeCombo,

							new sap.m.Button({
								icon: "sap-icon://add",
								press: $.proxy(this._addRequestData, this, bCreate, bUpdate, bDelete)
							}).addStyleClass("oDataTrackerButton")
						]
					})
				});
				return oPanel;
			},

			/**
			 * Shows Value Help on pressing in the Delete CRUD Panel
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			showDeleteValueHelp: function(oEvent) {
				var oModel = oEvent.getSource().getModel();
				var oDetailPageContext = this.byId("sampleDataDetailPage").getBindingContext();
				var oContext = oEvent.getSource().getBindingContext();
				var sEntitySet = oDetailPageContext.getProperty("name");

				if (!this.oDeleteValueHelpDialog) {
					this.oDeleteValueHelpDialog = sap.ui.xmlfragment("deleteValueHelpDialog", "sap.cd.ODataTracker.view.fragment.DeleteValueHelpDialog", this);
					this.getView().addDependent(this.oDeleteValueHelpDialog);
				}

				this.oDeleteValueHelpDialog.open();

				// Setting the Title of the Dialog
				this.oDeleteValueHelpDialog.setTitle(this.getI18nText("Delete_Value_Help_Dialog_Title") + sEntitySet);

				var oDeleteValueHelpTable = sap.ui.core.Fragment.byId("deleteValueHelpDialog", "deleteValueHelpTable");

				var oColumnListItem = new sap.m.ColumnListItem({
					type: "Active"
				});

				// Dynamically adding columns with property names
				oDeleteValueHelpTable.bindAggregation("columns", oContext.getPath() + "/property", function(sId, oContext) {
					// Get label & property for the column
					var sLabel = oContext.getProperty("name");
					var sValue = "{F4Help>" + oContext.getProperty("name") + "}";

					oColumnListItem.addCell(new sap.m.Text({
						text: sValue
					}));

					return new sap.m.Column(sId, {
						header: new sap.m.Text({
							text: sLabel,
							tooltip: sLabel
						})
					});
				});

				if (oColumnListItem) {
					oDeleteValueHelpTable.bindItems({
						path: "F4Help>/value",
						template: oColumnListItem
					});
				}

				this._oDialogContext = oContext;

				var oTableModel = new JSONModel();
				oDeleteValueHelpTable.setModel(oTableModel, "F4Help");

				$.ajax({
					type: "GET",
					url: oModel.getData().ServiceUrl + sEntitySet,
					dataType: "json",
					success: function(response) {
						if (!response.value && response.d.results) {
							response.value = {};
							response.value = response.d.results;
						}

						oTableModel.setData(response);
					},
					error: function(error) {
						// Showing the Error Message in the error Strip
						var oMessageStrip = sap.ui.core.Fragment.byId("deleteValueHelpDialog", "deleteValueHelpErrorMessage");
						oMessageStrip.setVisible(true);
						oMessageStrip.setText(error.responseJSON["odata.error"].message.value);
					}
				});
			},

			/**
			 * Handles the Press Event of a List Item in the Delete Value Help Dialog
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleDeleteValueHelpItemPressed: function(oEvent) {
				var oContext = oEvent.getSource().getSelectedItem().getBindingContext("F4Help");
				var aProperty = this._oDialogContext.getProperty("property");

				// Setting the selected list item to the Request Data
				for (var i = 0; i < aProperty.length; i++) {
					if (aProperty[i].key === true) {
						var vValue = oContext.getProperty(this._oDialogContext.getProperty("property")[i].name);
						if (vValue) {
							this.getView().getModel().setProperty(this._oDialogContext.getPath() + "/property/" + i + "/value", vValue);
							this.getView().getModel().setProperty(this._oDialogContext.getPath() + "/DataEntered", true);
						}
					}
				}
				this.oDeleteValueHelpDialog.close();
			},

			/**
			 * Handles the Press Event of the Cancel Button in the Delete Value Help Dialog
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleDeleteValueHelpCancelPressed: function() {
				this.oDeleteValueHelpDialog.close();
			},

			/**
			 * Creates the Detail Page of an Entity Set
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_createDetailPage: function() {
				var oDetailPage = this.byId("sampleDataDetailPage");
				this.byId("sampleDataDetailContent").destroyContent();
				var oController = this;

				var sContextPath = oDetailPage.getBindingContext().getPath();
				var oModel = this.getView().getModel();

				var sTitle = oDetailPage.getBindingContext().getProperty("name");
				oDetailPage.setTitle(sTitle);

				// Create
				var oCreatePanel = this._createDetailPageCRUDPanel("Create");
				this.byId("sampleDataDetailContent").addContent(oCreatePanel);
				oCreatePanel.bindAggregation("content", {
					path: sContextPath + "/crud/Create/RequestData/",
					factory: function(sId, oContext) {
						return oController._addContentsToDetailPagePanel(oContext.getPath(), true, false);
					}
				});

				// Read
				this._createReadPanel();

				// For Update
				var oUpdatePanel = this._createDetailPageCRUDPanel("Update");
				this.byId("sampleDataDetailContent").addContent(oUpdatePanel);
				oUpdatePanel.bindAggregation("content", {
					path: sContextPath + "/crud/Update/RequestData/",
					factory: function(sId, oContext) {
						return oController._addContentsToDetailPagePanel(oContext.getPath(), false, true, false);
					}
				});

				// Delete
				var oDeletePanel = this._createDetailPageCRUDPanel("Delete");
				this.byId("sampleDataDetailContent").addContent(oDeletePanel);
				var bDeletePanel = true;
				oDeletePanel.bindAggregation("content", {
					path: sContextPath + "/crud/Delete/RequestData/",
					factory: function(sId, oContext) {
						return oController._addContentsToDetailPagePanel(oContext.getPath(), false, false, true, bDeletePanel);
					}
				});
			},

			handleClearSampleData: function(oEvent) {
				var oModel = this.getView().getModel();
				var oClearButton = oEvent.getSource();
				var oContext = oClearButton.getBindingContext();
				var sCRUDOperation = oClearButton.data("CRUDOperation");

				if (!sCRUDOperation) {
					return;
				}

				var oDetailPage = this.byId("sampleDataDetailPage");
				var sDetailPageContextPath = oDetailPage.getBindingContext().getPath();

				// WorkAround
				oModel.setProperty(oContext.getPath() + "/Valid", true);
				oModel.setProperty(oContext.getPath() + "/DataEntered", false);
				var aProperties = oModel.getProperty(oContext.getPath() + "/property");
				for (var i = 0; i < aProperties.length; i++) {
					// TODO :Set value based on Property Type
					oModel.setProperty(oContext.getPath() + "/property/" + i + "/value", "");
					oModel.setProperty(oContext.getPath() + "/property/" + i + "/ValueState", "None");
				}
				// Below Code snippet is standard way of reseting values
				// but it will call the factory method again and recreate the layout , it will create some flickkering effect
				// var oEntityCopy = $.extend(true, {}, oModel.getProperty(sDetailPageContextPath + "/entity"));
				// oModel.setProperty(oContext.getPath(), oEntityCopy);
			},

			/**
			 * Adds content to the Detail Page of an Entity Set
			 * 
			 * @param: {string} sCurrentPath context path {boolean} bCreate flag for create {boolean} bUpdate flag for update {boolean} bDelete flag
			 *         for delete
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_addContentsToDetailPagePanel: function(sCurrentPath, bCreate, bUpdate, bDelete, bDeletePanel) {
				var oModel = this.getView().getModel();

				// TODO : Think of better solution
				var aPaths = sCurrentPath.split("/");
				var iIndex = parseInt(aPaths[aPaths.length - 1], 10);

				var oEntity = oModel.getProperty(sCurrentPath);
				var aProperties = oEntity.property;
				var sContextPath = this.byId("sampleDataDetailPage").getBindingContext().getPath();

				var oForm = new sap.ui.layout.form.SimpleForm({
					layout: "ResponsiveGridLayout",
					editable: true
				}).addStyleClass("oDataTrackerSampleDataForm");

				var sCRUDOperation = "";
				if (bCreate) {
					sCRUDOperation = "Create";
				} else if (bUpdate) {
					sCRUDOperation = "Update";
				} else if (bDelete) {
					sCRUDOperation = "Delete";
				}

				var oHeader = new sap.m.Toolbar({
					content: [
						new sap.m.Title({
							text: "Sample Data - " + (iIndex + 1)
						}).addStyleClass("oDataTrackerSampleDataFormTitle"), new sap.m.ToolbarSpacer(), new sap.m.Button({
							customData: [
								{
									Type: "sap.ui.core.CustomData",
									key: "CRUDOperation",
									value: sCRUDOperation
								}
							],
							icon: "sap-icon://eraser",
							press: $.proxy(this.handleClearSampleData, this)
						}).addStyleClass("oDataIconButton"), new sap.m.Button({
							customData: [
								{
									Type: "sap.ui.core.CustomData",
									key: "CRUDOperation",
									value: sCRUDOperation
								}
							],
							icon: "sap-icon://sys-cancel-2",
							press: $.proxy(this.handleDeleteSampleData, this)
						}).addStyleClass("oDataIconButton")
					]
				});

				// In the Delete Panel, include Button for List
				if (bDeletePanel) {
					var oDeleteListButton = new sap.m.Button(this.createId("toolbar" + iIndex), {
						// visible: false,
						icon: "sap-icon://list",
						press: $.proxy(this.showDeleteValueHelp, this)
					}).addStyleClass("oDataIconButton");
					oHeader.insertContent(oDeleteListButton, 2)
				}

				// Error Message to be displayed if data is entered and key fields aren't filled
				var oErrorMsg = new sap.m.MessageStrip({
					text: "{i18n>Sample_Data_Config_Entity_Sets_Error_Message}",
					type: sap.ui.core.MessageType.Error,
					visible: {
						path: sCurrentPath + "/Valid",
						formatter: function(bValid) {
							if (!bValid) {
								return true;
							} else {
								return false;
							}
						}
					}
				});

				var oVerticalLayout = new sap.ui.layout.VerticalLayout({});
				oVerticalLayout.addContent(oErrorMsg);
				oVerticalLayout.addContent(oHeader);

				oForm.addContent(oVerticalLayout);

				for (var i = 0; i < aProperties.length; i++) {
					if (aProperties[i].complexType || (bDelete && !aProperties[i].key)) {
						continue;
					}

					var iLength = aProperties[i].maxLength ? parseInt(aProperties[i].maxLength, 10) : 0;

					if (isNaN(iLength)) {
						iLength = 0;
					}

					var iPrecision = isNaN(aProperties[i].Precision) ? undefined : parseInt(aProperties[i].Precision, 10);
					var iScale = isNaN(aProperties[i].Scale) ? undefined : parseInt(aProperties[i].Scale, 10);

					var bNullable = aProperties[i].nullable ? aProperties[i].nullable : true;

					var sText = "";
					var oLabel = new sap.m.Label({});

					if (aProperties[i].key) {
						sText = aProperties[i].name + "-(k)";
						oLabel.setText(sText);
						oLabel.setTooltip(sText);
						oLabel.addStyleClass("oDataTrackerKeyProperty");

						if (!bCreate) {
							oLabel.setRequired(true);
						};
					} else if (aProperties[i].complexParent) {
						sText = aProperties[i].name + "-(C)";
						oLabel.setText(sText);
						oLabel.setTooltip(aProperties[i].name + "-(Complex Type)");
						oLabel.addStyleClass("oDataTrackerComplexProperty");
					} else {
						sText = aProperties[i].name;
						oLabel.setText(sText);
						oLabel.setTooltip(sText);
					}

					var oInput = null;
					var sValuePath = sCurrentPath + "/property/" + i + "/value";
					var sValueStatePath = sCurrentPath + "/property/" + i + "/ValueState";

					var oProperties = {
						MaxLength: iLength,
						Precision: iPrecision,
						Scale: iScale
					};

					var fnValueEventHandler = null;
					if (bUpdate || bDelete) {
						// Event Handler in case of Update
						fnValueEventHandler = function(oEvent) {
							var oSource = oEvent.getSource();
							var oContext = oSource.getBindingContext();
							var oModel = oContext.getModel();
							var sPath = oContext.getPath();
							var value, iErrorCount = 0;

							if (typeof oSource.getValue === "function") {
								value = oSource.getValue();
							} else if (typeof oSource.getSelectedKey === "function") {
								value = oSource.getSelectedKey();
							}

							var aProperties = oContext.getProperty("property");
							var bDataEntered = false;
							for (var i = 0; i < aProperties.length; i++) {
								if (aProperties[i].value) {
									bDataEntered = true;
								}
							}

							for (var i = 0; i < aProperties.length; i++) {
								if ((aProperties[i].key && aProperties[i].value) || (aProperties[i].key && !bDataEntered)) {
									oModel.setProperty(sPath + "/property/" + i + "/ValueState", "None");
								} else if (aProperties[i].key && !(aProperties[i].value)) {
									aProperties[i].ValueState = "Error";
									oModel.setProperty(sPath + "/property/" + i + "/ValueState", "Error");
									iErrorCount++;
								}
							}

							if (iErrorCount === 0) {
								oModel.setProperty(sPath + "/Valid", true);
							} else {
								oModel.setProperty(sPath + "/Valid", false);
							}

							if (bDataEntered) {
								oModel.setProperty(sPath + "/DataEntered", true);
							} else {
								oModel.setProperty(sPath + "/DataEntered", false);
							}
						};
					} else {
						// Event Handler in case of Delete
						fnValueEventHandler = function(oEvent) {
							var oSource = oEvent.getSource();
							var oContext = oSource.getBindingContext();
							var oModel = oContext.getModel();
							var sPath = oContext.getPath();
							var value, iErrorCount = 0;

							if (typeof oSource.getValue === "function") {
								value = oSource.getValue();
							} else if (typeof oSource.getSelectedKey === "function") {
								value = oSource.getSelectedKey();
							}

							var aProperties = oContext.getProperty("property");
							var bDataEntered = false;
							for (var i = 0; i < aProperties.length; i++) {
								if (aProperties[i].value) {
									bDataEntered = true;
								}
							}

							if (bDataEntered) {
								oModel.setProperty(sPath + "/DataEntered", true);
							} else {
								oModel.setProperty(sPath + "/DataEntered", false);
							}
						};
					}

					oInput = this._createControlForODataType(aProperties[i].type, sValuePath, oProperties, {}, sValueStatePath, fnValueEventHandler);

					oForm.addContent(oLabel);

					oForm.addContent(oInput);
				}
				return oForm;
			},

			/**
			 * 
			 * 
			 */
			_panelResizeHelper: function(oControl) {
				// WORKAROUND : For Flickering effect while adding or deleting sample data's
				// 1. Get Panel content Height and fix it as min-height till we finish re-creating the controls
				var oPanel = this._fnGivePanelRef(oControl);
				var iPanelCurrentHeight = oPanel.$().height();
				oPanel.$().css("height", iPanelCurrentHeight + "px");

				// 2. On After rendering of the panel , just change height to current height
				oPanel.addEventDelegate({
					onAfterRendering: function() {
						oPanel.$().css("height", "auto");
					}
				});
			},

			/**
			 * Adds Request Data to an Entity Set
			 * 
			 * @param: {boolean} bCreate flag for create {boolean} bUpdate flag for update {boolean} bDelete flag for delete
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_addRequestData: function(bCreate, bUpdate, bDelete, oEvent) {
				var oModel = this.getView().getModel();
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				var oEntityCopy = $.extend(true, {}, oModel.getProperty(sContextPath + "/entity"));

				// Get Entity
				var aEntities = [];
				var iIndex = 0;
				var sCurrentPath = "";

				this._panelResizeHelper(oEvent.getSource());
				if (bCreate) {

					aEntities = oModel.getProperty(sContextPath + "/crud/Create/RequestData");
					aEntities.push(oEntityCopy);
					iIndex = aEntities.length - 1;
					sCurrentPath = sContextPath + "/crud/Create/RequestData/" + iIndex;
					oModel.setProperty(sContextPath + "/crud/Create/RequestData", aEntities);

				} else if (bUpdate) {

					aEntities = oModel.getProperty(sContextPath + "/crud/Update/RequestData");
					aEntities.push(oEntityCopy);
					iIndex = aEntities.length - 1;
					sCurrentPath = sContextPath + "/crud/Update/RequestData/" + iIndex;

					oModel.setProperty(sContextPath + "/crud/Update/RequestData", aEntities);
				} else if (bDelete) {

					aEntities = oModel.getProperty(sContextPath + "/crud/Delete/RequestData");
					aEntities.push(oEntityCopy);
					iIndex = aEntities.length - 1;
					sCurrentPath = sContextPath + "/crud/Delete/RequestData/" + iIndex;

					oModel.setProperty(sContextPath + "/crud/Delete/RequestData", aEntities);
				}
			},

			_createReadRequestData: function(bSingleFilter, bGroupFilter) {
				// For Read
				var oRequestData = {
					"OnlyRead": false,
					"DataEntered": false,
					"Filter": [
						{
							"MultiOperatorVisible": false,
							"Property": "",
							"Operator": "",
							"Value1": "",
							"Value2": "",
							"DataType": "",
							"bAnd": true,
							"Type": "Single"
						}
					],
					"SorterAsc": [],
					"SorterDesc": [],
					"Select": [],
					"Expand": []
				};

				if (bSingleFilter) {
					return $.extend(true, {}, oRequestData.Filter[0]);
				} else if (bGroupFilter) {
					return $.extend(true, {}, {
						"MultiOperatorVisible": false,
						"bAnd": true,
						"Type": "Group",
						"SubFilters": [
							{
								"MultiOperatorVisible": false,
								"Property": "",
								"Operator": "",
								"Value1": "",
								"Value2": "",
								"bAnd": true,
								"DataType": "",
								"Type": "Single"
							}
						]
					});
				} else {
					return $.extend(true, {}, oRequestData);
				}
			},

			_createReadPanel: function() {
				var oModel = this.getView().getModel();
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();
				var aEntities = oModel.getProperty(sContextPath + "/crud/Read/RequestData") ? oModel.getProperty(sContextPath + "/crud/Read/RequestData") : [];

				// Create Initial Read Request Data
				if (aEntities.length <= 0) {
					var oInitalRequestData = this._createReadRequestData();
					oModel.setProperty(sContextPath + "/crud/Read/RequestData/0", oInitalRequestData);
				}

				// Create Panel
				var oReadPanel = new sap.m.Panel(this.createId("Read_Panel"), {
					expandable: true,
					visible: {
						path: sContextPath + "/crud/Read/Available",
						formatter: function(bCRUD) {
							if (bCRUD) {
								return true;
							} else {
								return false;
							}
						}
					},
					expanded: true,
					width: "auto",
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Text({
								text: "Read"
							}),

							new sap.m.ToolbarSpacer(),

							new sap.m.Button({
								icon: "sap-icon://add",
								press: $.proxy(this._handleAddReadSampleData, this)
							}).addStyleClass("oDataTrackerButton")
						]
					})
				}).addStyleClass("sapUiContentPadding");

				this.byId("sampleDataDetailContent").addContent(oReadPanel);

				var oController = this;
				oReadPanel.bindAggregation("content", {
					path: sContextPath + "/crud/Read/RequestData/",
					factory: function(sId, oContext) {
						var oReadLayout = oController._createReadDataLayout(sContextPath, oContext.getPath());

						if (oReadPanel.getContent() && oReadPanel.getContent().length > 0) {
							oReadLayout.addStyleClass("oDataTrackerReadPanelBorder");
						}

						return oReadLayout;
					}
				});
			},

			_handleAddReadSampleData: function(oEvent) {
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				this._panelResizeHelper(oEvent.getSource());
				var oModel = this.getView().getModel();
				var oReadRequestData = this._createReadRequestData();
				var aReadSampleData = oModel.getProperty(sContextPath + "/crud/Read/RequestData/");
				aReadSampleData.push(oReadRequestData);
				oModel.setProperty(sContextPath + "/crud/Read/RequestData/", aReadSampleData);
			},

			_handleReadOnlySelected: function(oEvent) {
				var oCheckBox = oEvent.getSource();
				var oModel = this.getView().getModel();
				var sPath = oCheckBox.getBindingContext().getPath();

				if (oCheckBox.getSelected()) {
					oModel.setProperty(sPath + "/Valid", true);
					oModel.setProperty(sPath + "/DataEntered", true);
				}
			},
			_createReadDataLayout: function(sItemPressContextPath, sReadRequestPath) {
				// Create Layout
				var oModel = this.getView().getModel();
				// Add - Read with no parameters CheckBox
				var oLayout = new sap.ui.layout.VerticalLayout({}).addStyleClass("sapUiContentPadding oDataTrackerReadLayout");

				var aPaths = sReadRequestPath.split("/");
				var iIndex = parseInt(aPaths[aPaths.length - 1], 10);

				var oHeader = new sap.m.Toolbar({
					content: [
						new sap.m.Title({
							text: "Sample Data - " + (iIndex + 1)
						}).addStyleClass("oDataTrackerSampleDataFormTitle"), new sap.m.ToolbarSpacer(), new sap.m.Button({
							customData: [
								{
									Type: "sap.ui.core.CustomData",
									key: "CRUDOperation",
									value: "Read"
								}
							],
							icon: "sap-icon://sys-cancel-2",
							press: $.proxy(this.handleDeleteSampleData, this)
						}).addStyleClass("oDataIconButton")
					]
				});

				oLayout.addContent(oHeader);
				// Create Read Only ComboBox
				var oReadOnlyCheckBox = new sap.m.CheckBox({
					text: "Read with no parameters",
					selected: "{" + sReadRequestPath + "/OnlyRead}",
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "ReadRequestPath",
							value: sReadRequestPath
						}
					],
					select: $.proxy(this._handleReadOnlySelected, this)
				});

				oLayout.addContent(oReadOnlyCheckBox);

				var oReadWithParamLayout = new sap.ui.layout.VerticalLayout({
					width: "100%",
					visible: {
						path: sReadRequestPath + "/OnlyRead",
						formatter: function(bReadOnly) {
							return !bReadOnly;
						}
					}
				});
				oLayout.addContent(oReadWithParamLayout);

				// Create Filter Layout
				var sFilterId = (sReadRequestPath + "Filter_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oFilterLayout = new sap.ui.layout.VerticalLayout(this.createId(sFilterId), {
					width: "100%"
				});
				var aFilters = oModel.getProperty(sReadRequestPath + "/Filter");

				// Create Title
				// Add Filter Button
				var oSingleFilterAddButton = new sap.m.Button({
					text: "Single",
					icon: "sap-icon://add",
					iconFirst: false,
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterActionButton",
							value: true
						}, {
							Type: "sap.ui.core.CustomData",
							key: "ReadRequestPath",
							value: sReadRequestPath
						}
					],
					press: $.proxy(this.handleFilterAdd, this, false)
				}).addStyleClass("sapUiSmallMarginBegin oDataTrackerButton");

				var oGroupFilterAddButton = new sap.m.Button({
					text: "Group",
					icon: "sap-icon://add",
					iconFirst: false,
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterActionButton",
							value: true
						}, {
							Type: "sap.ui.core.CustomData",
							key: "ReadRequestPath",
							value: sReadRequestPath
						}
					],
					press: $.proxy(this.handleGroupFilterAdd, this)
				}).addStyleClass("sapUiSmallMarginBegin oDataTrackerButton");

				var oFilterHeaderBar = new sap.m.Toolbar({
					width: "100%",
					content: [
						new sap.m.Label({
							text: "Filter"
						}), oSingleFilterAddButton, oGroupFilterAddButton
					]
				});

				oReadWithParamLayout.addContent(oFilterHeaderBar);

				// Loop through the filters array
				for (var i = 0; i < aFilters.length; i++) {
					var sId = (sReadRequestPath + "/Filter/" + i).replace(/[^a-zA-Z0-9_]/g, "_");
					var oFilterContent = null;
					if (aFilters[i].Type === "Single") {
						oFilterContent = this._createSingleFilterLayout(sId, i, sItemPressContextPath, sReadRequestPath);
					} else if (aFilters[i].Type === "Group") {
						oFilterContent = this._createGroupFilterLayout(sId, i, sItemPressContextPath, sReadRequestPath);
					}

					oFilterLayout.addContent(oFilterContent);
				}
				oReadWithParamLayout.addContent(oFilterLayout);

				//  ***** Create Sorter Layout *****//
				// Create Ascending Layout
				var sSortAscId = (sReadRequestPath + "Sort_Asc_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oSortAscLayout = new sap.ui.layout.VerticalLayout(this.createId(sSortAscId), {
					width: "100%"
				}).addStyleClass("sapUiMediumMarginTop");
				var aSortAscProps = oModel.getProperty(sReadRequestPath + "/SorterAsc");

				var oSortAscTitle = new sap.m.Title({
					text: "Sort Ascending"
				});
				oSortAscLayout.addContent(oSortAscTitle);

				var oSortAscProperties = new sap.m.MultiComboBox({
					items: {
						path: sItemPressContextPath + "/entity/property",
						filters : [new sap.ui.model.Filter("complexType", sap.ui.model.FilterOperator.NE, true)],
						template: new sap.ui.core.Item({
							text: "{name}",
							key: "{name}"
						})
					},
					selectedKeys: aSortAscProps,
					selectionFinish: function(oEvent) {
						var aSelectedItems = oEvent.getParameter("selectedItems");
						var aSelectedProperties = [];
						for (var i = 0; i < aSelectedItems.length; i++) {
							aSelectedProperties.push(aSelectedItems[i].getKey());
						}
						oModel.setProperty(sReadRequestPath + "/SorterAsc/", aSelectedProperties);
					}
				});
				oSortAscLayout.addContent(oSortAscProperties);
				oReadWithParamLayout.addContent(oSortAscLayout);

				// Create Descending Layout
				var sSortDescId = (sReadRequestPath + "Sort_Desc_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oSortDescLayout = new sap.ui.layout.VerticalLayout(this.createId(sSortDescId), {
					width: "100%"
				}).addStyleClass("sapUiMediumMarginTop");
				var aSortDescProps = oModel.getProperty(sReadRequestPath + "/SorterDesc");

				var oSortDescTitle = new sap.m.Title({
					text: "Sort Descending"
				});
				oSortDescLayout.addContent(oSortDescTitle);

				var oSortDescProperties = new sap.m.MultiComboBox({
					items: {
						path: sItemPressContextPath + "/entity/property",
						filters : [new sap.ui.model.Filter("complexType", sap.ui.model.FilterOperator.NE, true)],
						template: new sap.ui.core.Item({
							text: "{name}",
							key: "{name}"
						})
					},
					selectedKeys: aSortDescProps,
					selectionFinish: function(oEvent) {
						var aSelectedItems = oEvent.getParameter("selectedItems");
						var aSelectedProperties = [];
						for (var i = 0; i < aSelectedItems.length; i++) {
							aSelectedProperties.push(aSelectedItems[i].getKey());
						}
						oModel.setProperty(sReadRequestPath + "/SorterDesc/", aSelectedProperties);
					}
				});
				oSortDescLayout.addContent(oSortDescProperties);
				oReadWithParamLayout.addContent(oSortDescLayout);

				// Create Select Layout
				var sSelectId = (sReadRequestPath + "Select_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oSelectLayout = new sap.ui.layout.VerticalLayout(this.createId(sSelectId), {
					width: "100%"
				}).addStyleClass("sapUiMediumMarginTop");
				var aSelectProps = oModel.getProperty(sReadRequestPath + "/Select");

				var oSelectTitle = new sap.m.Title({
					text: "Select"
				});
				oSelectLayout.addContent(oSelectTitle);

				var oSelectProperties = new sap.m.MultiComboBox({
					items: {
						path: sItemPressContextPath + "/entity/property",
						filters : [new sap.ui.model.Filter("complexParent", sap.ui.model.FilterOperator.EQ, false)],
						template: new sap.ui.core.Item({
							text: "{name}",
							key: "{name}"
						})
					},
					selectedKeys: aSelectProps,
					selectionFinish: function(oEvent) {
						var aSelectedItems = oEvent.getParameter("selectedItems");
						var aSelectedProperties = [];
						for (var i = 0; i < aSelectedItems.length; i++) {
							aSelectedProperties.push(aSelectedItems[i].getKey());
						}
						oModel.setProperty(sReadRequestPath + "/Select/", aSelectedProperties);
						if (aSelectedProperties && aSelectedProperties.length > 0) {
							oModel.setProperty(sReadRequestPath + "/DataEntered", true);
						}
					}
				});
				oSelectLayout.addContent(oSelectProperties);

				oReadWithParamLayout.addContent(oSelectLayout);

				// Create Expand Layout
				var sExpandId = (sReadRequestPath + "Expand_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oExpandLayout = new sap.ui.layout.VerticalLayout(this.createId(sExpandId), {
					width: "100%"
				}).addStyleClass("sapUiMediumMarginTop");
				var aExpands = oModel.getProperty(sReadRequestPath + "/Expand");

				var oExpandTitle = new sap.m.Title({
					text: "Expand"
				});
				oExpandLayout.addContent(oExpandTitle);

				var sExpandPath = sItemPressContextPath + "/entity/navigationProperty";
				var oExpandEntities = new sap.m.MultiComboBox({
					items: {
						path: sExpandPath,
						template: new sap.ui.core.Item({
							text: "{name}",
							key: "{name}"
						})
					},
					selectedKeys: aExpands,
					selectionFinish: function(oEvent) {
						var aSelectedItems = oEvent.getParameter("selectedItems");
						var aSelectedKeys = [];
						for (var i = 0; i < aSelectedItems.length; i++) {
							aSelectedKeys.push(aSelectedItems[i].getKey());
						}
						oModel.setProperty(sReadRequestPath + "/Expand/", aSelectedKeys);
					}
				});
				oExpandLayout.addContent(oExpandEntities);

				oReadWithParamLayout.addContent(oExpandLayout);
				return oLayout;
			},

			handleGroupFilterAdd: function(oEvent) {
				var oModel = this.getView().getModel();
				var oAddButton = oEvent.getSource();
				var sReadRequestPath = oAddButton.data("ReadRequestPath");
				var oFilter = this._createReadRequestData(false/* Single */, true/* Group */);
				var aFilters = oModel.getProperty(sReadRequestPath + "/Filter");

				aFilters.push(oFilter);
				oModel.setProperty(sReadRequestPath + "/Filter", aFilters);

				var iIndex = aFilters.length - 1;
				var sId = (sReadRequestPath + "/Filter/" + iIndex).replace(/[^a-zA-Z0-9_]/g, "_");
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				// Update "MultiOperatorVisible" property
				for (var i = 0; i < aFilters.length; i++) {
					if (i === aFilters.length - 1) {
						oModel.setProperty(sReadRequestPath + "/Filter/" + i + "/MultiOperatorVisible", false);
					} else {
						oModel.setProperty(sReadRequestPath + "/Filter/" + i + "/MultiOperatorVisible", true);
					}
				}

				var oFilterContent = this._createGroupFilterLayout(sId, iIndex, sContextPath, sReadRequestPath);
				var sFilterId = (sReadRequestPath + "Filter_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oFilterLayout = this.byId(sFilterId);
				oFilterLayout.addContent(oFilterContent);
			},

			_createGroupFilterLayout: function(sId, iIndex, sItemPressContextPath, sReadRequestPath) {
				var oWrapper = new sap.ui.layout.VerticalLayout({
					width: "100%"
				});

				// Create Overall wrapper
				var oGroupFilterWrapper = new sap.ui.layout.VerticalLayout(this.createId(sId), {});

				// Create Header Toolbar
				var oHeader = new sap.m.Toolbar({
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "ReadRequestPath",
							value: sReadRequestPath
						}
					],
					content: [
						new sap.m.Text({
							text: "Group Filter (Filters will be created with parenthesis)"
						}).addStyleClass("oDataLargeText"),

						new sap.m.ToolbarSpacer(),

						new sap.m.Button({
							icon: "sap-icon://add",
							customData: [
								{
									Type: "sap.ui.core.CustomData",
									key: "ReadRequestPath",
									value: sReadRequestPath
								}, {
									Type: "sap.ui.core.CustomData",
									key: "MainFilterIndex",
									value: iIndex
								}
							],
							press: $.proxy(this.handleFilterAdd, this, true)
						}).addStyleClass("oDataIconButton"),

						new sap.m.Button({
							icon: "sap-icon://sys-cancel-2",
							customData: [
								{
									Type: "sap.ui.core.CustomData",
									key: "CurrentPath",
									value: sReadRequestPath + "/Filter/" + iIndex
								}
							],
							press: $.proxy(this.handleFilterDelete, this)
						}).addStyleClass("oDataIconButton")
					]
				});
				var oGroupFilterOuterWrapper = new sap.ui.layout.VerticalLayout({
					content: [
						oHeader, oGroupFilterWrapper
					]
				}).addStyleClass("oDataTrackerGrpFilterLayout");

				// Loop through the subFilters and create layout
				var oModel = this.getView().getModel();
				var aSubFilters = oModel.getProperty(sReadRequestPath + "/Filter/" + iIndex + "/SubFilters/");
				for (var itrIndex = 0; itrIndex < aSubFilters.length; itrIndex++) {
					var sId = (sReadRequestPath + "/Filter/" + iIndex + "/SubFilters/" + itrIndex).replace(/[^a-zA-Z0-9_]/g, "_");
					var oSingleFilter = this._createSingleFilterLayout(sId, iIndex, sItemPressContextPath, sReadRequestPath + "/Filter/" + iIndex, true, itrIndex);
					oGroupFilterWrapper.addContent(oSingleFilter);
				}
				oWrapper.addContent(oGroupFilterOuterWrapper);

				var oMutliFilterSwitch = new sap.m.Switch({
					visible: "{" + sReadRequestPath + "/Filter/" + iIndex + "/MultiOperatorVisible}",
					customTextOn: "And",
					customTextOff: "Or",
					state: "{" + sReadRequestPath + "/Filter/" + iIndex + "/bAnd}"
				}).addStyleClass("sapUiSmallMarginBegin");
				oWrapper.addContent(oMutliFilterSwitch);
				return oWrapper;
			},

			_createSingleFilterLayout: function(sId, iIndex, sItemPressContextPath, sReadRequestPath, bFromGroupFilter, iSubFilterIndex) {

				// Create Filter Layout
				var oFilterContent = new sap.ui.layout.HorizontalLayout(this.createId(sId), {
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "ReadRequestPath",
							value: sReadRequestPath
						}, {
							Type: "sap.ui.core.CustomData",
							key: "FilterIndex",
							value: iIndex
						}

					]
				});

				var oFilterWrapper = new sap.ui.layout.VerticalLayout({
					content: oFilterContent
				});

				var sCurrentFilterPath = "";
				if (bFromGroupFilter) {
					sCurrentFilterPath = sReadRequestPath + "/SubFilters/" + iSubFilterIndex;
				} else {
					sCurrentFilterPath = sReadRequestPath + "/Filter/" + iIndex;
				}

				// Create Filter Property ComboBox
				var oFilterPropertyCombo = new sap.m.ComboBox({
					selectedKey: "{" + sCurrentFilterPath + "/Property}",
					placeholder: "Property",
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterPath",
							value: sCurrentFilterPath
						}, {
							Type: "sap.ui.core.CustomData",
							key: "PropertyPath",
							value: ""
						}
					],
					items: {
						path: sItemPressContextPath + "/entity/property",
						filters : [new sap.ui.model.Filter("complexType", sap.ui.model.FilterOperator.NE, true)],
						template: new sap.ui.core.Item({
							text: "{name}",
							key: "{name}"
						})
					},
					selectionChange: $.proxy(function(oEvent) {
						var sPropertyContextPath = oEvent.getSource().getSelectedItem().getBindingContext().getPath();
						this.setCustomData(oEvent.getSource(), "PropertyPath", sPropertyContextPath);
						this.setCustomData(oFilterOperator, "PropertyPath", sPropertyContextPath);
						this._handlePropertyChange(bFromGroupFilter, oEvent);
					}, this)
				}).addStyleClass("sapUiMediumMarginEnd");

				oFilterContent.addContent(oFilterPropertyCombo);

				// Create Filter Operator
				var oFilterOperator = new sap.m.ComboBox({
					enabled: {
						path: sCurrentFilterPath + "/Property",
						formatter: function(sProperty) {
							if (sProperty) {
								return true;
							} else {
								return false;
							}
						}
					},
					selectedKey: "{" + sCurrentFilterPath + "/Operator}",
					placeholder: "Filter Operator",
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterPath",
							value: sCurrentFilterPath
						}, {
							Type: "sap.ui.core.CustomData",
							key: "PropertyPath",
							value: ""
						}
					],
					items: {
						path: "/FilterOperators",
						template: new sap.ui.core.Item({
							text: "{OperatorName}",
							key: "{OperatorKey}"
						})
					},
					selectionChange: $.proxy(function(oEvent) {
						this._handlePropertyChange(bFromGroupFilter, oEvent);
					}, this)
				}).addStyleClass("sapUiMediumMarginEnd");
				oFilterContent.addContent(oFilterOperator);

				// Create Filter ValueField
				// Add onAfterRendering Event delegate

				var $FilterPropertyDeferred = $.Deferred();
				var sFilterPath = sCurrentFilterPath;
				var sPropertyContextPath;

				// TODO : Check for Better solution
				oFilterPropertyCombo.addEventDelegate({
					onAfterRendering: function() {
						if (oFilterPropertyCombo.getSelectedItem()) {

							sPropertyContextPath = oFilterPropertyCombo.getSelectedItem().getBindingContext().getPath();

							this.setCustomData(oFilterPropertyCombo, "PropertyPath", sPropertyContextPath);
							this.setCustomData(oFilterOperator, "PropertyPath", sPropertyContextPath);

							$FilterPropertyDeferred.resolve();
						}
					}
				}, this);

				jQuery.when($FilterPropertyDeferred).then(jQuery.proxy(function() {
					this._createFilterValueField(oFilterContent, sFilterPath, sPropertyContextPath, bFromGroupFilter);
				}, this));

				var oMutliFilterSwitch = new sap.m.Switch({
					visible: "{" + sCurrentFilterPath + "/MultiOperatorVisible}",
					customTextOn: "And",
					customTextOff: "Or",
					state: "{" + sCurrentFilterPath + "/bAnd}"
				}).addStyleClass("sapUiSmallMarginBegin");
				oFilterWrapper.addContent(oMutliFilterSwitch);

				var fnDeleteHandler = null;
				if (!!bFromGroupFilter) {
					fnDeleteHandler = $.proxy(this.handleSubFilterDelete, this, iIndex);
				} else {
					fnDeleteHandler = $.proxy(this.handleFilterDelete, this);
				}
				var oFilterDeleteButton = new sap.m.Button({
					icon: "sap-icon://sys-cancel-2",
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterActionButton",
							value: true
						}, {
							Type: "sap.ui.core.CustomData",
							key: "CurrentPath",
							value: sFilterPath
						}
					],
					press: fnDeleteHandler
				}).addStyleClass("sapUiMediumMarginBegin oDataIconButton");

				oFilterContent.addContent(oFilterDeleteButton);

				return oFilterWrapper;
			},

			setCustomData: function(oControl, sKey, sNewValue) {
				var aCustomDatas = oControl.getCustomData();

				$.each(aCustomDatas, function(iIndex, oCustomData) {
					if (oCustomData.getKey() === sKey) {
						oCustomData.setValue(sNewValue);
					}
				});
			},

			_handlePropertyChange: function(bFromGroupFilter, oEvent) {
				var oComboBox = oEvent.getSource();
				var sCurrentPath = oComboBox.data("FilterPath");

				var sId = sCurrentPath.replace(/[^a-zA-Z0-9_]/g, "_");
				var oLayout = this.byId(sId);

				var sContextPath = oComboBox.data("PropertyPath");
				if (!sContextPath) {
					return;
				}
				this._createFilterValueField(oLayout, sCurrentPath, sContextPath, bFromGroupFilter);
			},

			_createFilterValueField: function(oLayout, sFilterCurrentPath, sContextPath, bFromGroupFilter) {
				var aLayoutContents = oLayout.getContent();
				for (var i = 0; i < aLayoutContents.length; i++) {
					if (aLayoutContents[i].data("bValueField") || aLayoutContents[i].data("FilterActionButton")) {
						oLayout.removeContent(aLayoutContents[i]);
					}
				}

				var oModel = this.getView().getModel();
				var oProperty = oModel.getProperty(sContextPath);
				var iMaxLength = isNaN(oProperty.maxLength) ? 0 : parseInt(oProperty.maxLength, 10);
				var oInput;
				var oSecondInput;

				var sFilterkey = oModel.getProperty(sFilterCurrentPath + "/Operator");

				var sValuePath1 = sFilterCurrentPath + "/Value1";
				var aCustomData = [];
				aCustomData = [
					{
						Type: "sap.ui.core.CustomData",
						key: "bValueField",
						value: true
					}
				];

				var iPrecision = isNaN(oProperty.Precision) ? undefined : parseInt(oProperty.Precision, 10);
				var iScale = isNaN(oProperty.Scale) ? undefined : parseInt(oProperty.Scale, 10);

				var oProperties = {
					MaxLength: iMaxLength,
					Precision: iPrecision,
					Scale: iScale
				};

				// Set Type 
				oModel.setProperty(sFilterCurrentPath + "/DataType", oProperty.type);

				var sValueStatePath = sFilterCurrentPath + "/ValueState";
				oInput = this._createControlForODataType(oProperty.type, sValuePath1, oProperties, aCustomData, sValueStatePath);

				if (sFilterkey === sap.ui.model.FilterOperator.BT) {
					var sValuePath2 = sFilterCurrentPath + "/Value2";
					oSecondInput = this._createControlForODataType(oProperty.type, sValuePath2, oProperties, aCustomData, sValueStatePath);
					oLayout.addContent(oSecondInput);
				} else {
					oModel.setProperty(sFilterCurrentPath + "/Value2", "");
				}

				oLayout.addContent(oInput);

				var sReadRequestPath = oLayout.data("ReadRequestPath");

				var fnDeleteHandler = null;
				if (!!bFromGroupFilter) {
					var iFilterIndex = oLayout.data("FilterIndex");
					fnDeleteHandler = $.proxy(this.handleSubFilterDelete, this, iFilterIndex);
				} else {
					fnDeleteHandler = $.proxy(this.handleFilterDelete, this);
				}

				var oFilterDeleteButton = new sap.m.Button({
					icon: "sap-icon://sys-cancel-2",
					customData: [
						{
							Type: "sap.ui.core.CustomData",
							key: "FilterActionButton",
							value: true
						}, {
							Type: "sap.ui.core.CustomData",
							key: "CurrentPath",
							value: sFilterCurrentPath
						}
					],
					press: fnDeleteHandler
				}).addStyleClass("sapUiMediumMarginBegin oDataIconButton");
				oLayout.addContent(oFilterDeleteButton);
			},

			/**
			 * TODO
			 */
			handleFilterAdd: function(bGroupFilter, oEvent) {
				var oModel = this.getView().getModel();
				var oAddButton = oEvent.getSource();
				var sReadRequestPath = oAddButton.data("ReadRequestPath");
				var oFilter = this._createReadRequestData(true);
				var sAddPath = "";
				var sFilterId;
				var iMainFilterIndex;
				if (bGroupFilter) {
					iMainFilterIndex = oAddButton.data("MainFilterIndex");
					sAddPath = sReadRequestPath + "/Filter/" + iMainFilterIndex + "/SubFilters";
					sFilterId = (sReadRequestPath + "/Filter/" + iMainFilterIndex).replace(/[^a-zA-Z0-9_]/g, "_");
				} else {
					sAddPath = sReadRequestPath + "/Filter";
					sFilterId = (sReadRequestPath + "Filter_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				}

				var oFilterLayout = this.byId(sFilterId);
				var aFilters = oModel.getProperty(sAddPath);

				aFilters.push(oFilter);
				oModel.setProperty(sAddPath, aFilters);

				var iIndex = aFilters.length - 1;
				var sId = (sAddPath + "/" + iIndex).replace(/[^a-zA-Z0-9_]/g, "_");
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				// Update "MultiOperatorVisible" property
				for (var i = 0; i < aFilters.length; i++) {
					if (i === aFilters.length - 1) {
						oModel.setProperty(sAddPath + "/" + i + "/MultiOperatorVisible", false);
					} else {
						oModel.setProperty(sAddPath + "/" + i + "/MultiOperatorVisible", true);
					}
				}

				var oFilterContent = null;
				if (bGroupFilter) {
					oFilterContent = this._createSingleFilterLayout(sId, iMainFilterIndex, sContextPath, sReadRequestPath + "/Filter/" + iMainFilterIndex, true, iIndex);
				} else {
					oFilterContent = this._createSingleFilterLayout(sId, iIndex, sContextPath, sReadRequestPath);
				}
				oFilterLayout.addContent(oFilterContent);
			},

			/**
			 * Deletes Sample Data from an Entity Set
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleDeleteSampleData: function(oEvent) {
				var oModel = this.getView().getModel();
				var oDeleteButton = oEvent.getSource();
				var oContext = oDeleteButton.getBindingContext();
				var sCRUDOperation = oDeleteButton.data("CRUDOperation");

				if (!sCRUDOperation) {
					return;
				}

				this._panelResizeHelper(oDeleteButton);
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sDetailPageContextPath = oDetailPage.getBindingContext().getPath();

				var aReqDatas = oModel.getProperty(sDetailPageContextPath + "/crud/" + sCRUDOperation + "/RequestData");

				if (!aReqDatas || aReqDatas.length <= 1) {
					return;
				}
				var iIndex = aReqDatas.indexOf(oModel.getProperty(oContext.getPath()));
				if (iIndex !== -1) {
					aReqDatas.splice(iIndex, 1);
				}
				oModel.setProperty(sDetailPageContextPath + "/crud/" + sCRUDOperation + "/RequestData", aReqDatas);
			},

			/**
			 * 
			 */
			handleFilterDelete: function(oEvent) {
				var oModel = this.getView().getModel();
				var oDeleteButton = oEvent.getSource();
				var sCurrentPath = oDeleteButton.data("CurrentPath");
				var sReadRequestPath = oDeleteButton.getParent().data("ReadRequestPath");

				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				var sPath;
				sPath = sReadRequestPath + "/Filter";

				if (oModel.getProperty(sPath).length <= 1) {
					return;
				}
				oModel.setProperty(sCurrentPath, {});
				var aFilters = oModel.getProperty(sPath);

				var aNewFilters = [];
				for (var i = 0; i < aFilters.length; i++) {
					if (!$.isEmptyObject(aFilters[i])) {
						aNewFilters.push(aFilters[i]);
					}
				}

				oModel.setProperty(sPath, aNewFilters);

				// Loop through the filtes array
				var sFilterId = (sReadRequestPath + "Filter_Layout").replace(/[^a-zA-Z0-9_]/g, "_");
				var oFilterLayout = this.byId(sFilterId);
				oFilterLayout.destroyContent();

				for (var i = 0; i < aNewFilters.length; i++) {
					if (i === aNewFilters.length - 1) {
						oModel.setProperty(sPath + "/" + i + "/MultiOperatorVisible", false);
					} else {
						oModel.setProperty(sPath + "/" + i + "/MultiOperatorVisible", true);
					}

					var sId = (sPath + "/" + i).replace(/[^a-zA-Z0-9_]/g, "_");
					var oFilterContent = null;
					if (aNewFilters[i].Type === "Single") {
						oFilterContent = this._createSingleFilterLayout(sId, i, sContextPath, sReadRequestPath);
					} else if (aNewFilters[i].Type === "Group") {
						oFilterContent = this._createGroupFilterLayout(sId, i, sContextPath, sReadRequestPath);
					}
					oFilterLayout.addContent(oFilterContent);
				}
			},

			handleSubFilterDelete: function(iIndex, oEvent) {
				var oModel = this.getView().getModel();
				var oDeleteButton = oEvent.getSource();
				var sCurrentPath = oDeleteButton.data("CurrentPath");
				var sReadRequestPath = oDeleteButton.getParent().data("ReadRequestPath");

				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				var sPath = sReadRequestPath + "/SubFilters";

				if (oModel.getProperty(sPath).length <= 1) {
					return;
				}

				oModel.setProperty(sCurrentPath, {});
				var aFilters = oModel.getProperty(sPath);

				var aNewFilters = [];
				for (var i = 0; i < aFilters.length; i++) {
					if (!$.isEmptyObject(aFilters[i])) {
						aNewFilters.push(aFilters[i]);
					}
				}

				oModel.setProperty(sPath, aNewFilters);

				// Loop through the filtes array
				var sFilterId = (sReadRequestPath).replace(/[^a-zA-Z0-9_]/g, "_");
				var oFilterLayout = this.byId(sFilterId);
				oFilterLayout.destroyContent();

				for (var i = 0; i < aNewFilters.length; i++) {
					if (i === aNewFilters.length - 1) {
						oModel.setProperty(sPath + "/" + i + "/MultiOperatorVisible", false);
					} else {
						oModel.setProperty(sPath + "/" + i + "/MultiOperatorVisible", true);
					}

					var sId = (sPath + "/" + i).replace(/[^a-zA-Z0-9_]/g, "_");
					var oFilterContent = null;
					if (aNewFilters[i].Type === "Single") {
						oFilterContent = this._createSingleFilterLayout(sId, iIndex, sContextPath, sReadRequestPath, true, i);
					}
					oFilterLayout.addContent(oFilterContent);
				}
			},

			/**
			 * 
			 */
			_createControlForODataType: function(sType, sValuePath, oProperties, aCustomData, sValueStatePath, fnValueEventHandler) {
				var oControl = null;
				/*
				 * var oProperties = { MaxLength: iLength, Precision: iPrecision, Scale: iScale };
				 */
				switch (sType) {
					case "Edm.Int":
					case "Edm.Byte":
					case "Edm.SByte":
					case "Edm.Int16":
					case "Edm.Int32":
					case "Edm.Int64":
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Time":
						oControl = new sap.m.Input({
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.Time"
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.DateTime":
						oControl = new sap.m.DatePicker({
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.DateTime",
								formatOptions: {
									pattern: 'yyyy-MM-dd\'T\'HH:mm:ss',
									UTC: true
								}
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Boolean":
						oControl = new sap.m.Select({
							customData: aCustomData,
							selectedKey: {
								path: sValuePath,
								type: "sap.ui.model.type.Boolean"
							},
							items: [
								new sap.ui.core.Item({
									text: "",
									key: ""
								}), new sap.ui.core.Item({
									text: "True",
									key: "true"
								}), new sap.ui.core.Item({
									text: "False",
									key: "false"
								})
							]
						});
						break;
					case "Edm.Decimal":
						// TODO: have type with float and constraints
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties.Precision ? oProperties.Precision : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.Double":
					case "Edm.Single":
						// TODO : have type with float and constraints
						oControl = new sap.m.Input({
							type: "Number",
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;

					case "Edm.String":
					case "Edm.Guid":
					default:
						oControl = new sap.m.Input({
							maxLength: oProperties ? oProperties.MaxLength : 0,
							customData: aCustomData,
							value: {
								path: sValuePath,
								type: "sap.ui.model.type.String"
							},
							valueState: "{" + sValueStatePath + "}"
						});
						break;
				}

				if (typeof fnValueEventHandler === "function") {
					if (oControl instanceof sap.m.Input || oControl instanceof sap.m.DatePicker || oControl instanceof sap.m.Select) {
						oControl.attachChange($.proxy(fnValueEventHandler, this));
					}
				}

				return oControl;
			},

			/**
			 * Handles the Press Event of a List Item of the Function Imports List
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleFnImportListItemPressed: function(oEvent) {
				this.byId("sampleDataMasterList").removeSelections();
				this.byId("CRUDOperationChangeLayout").setVisible(false);

				var oDetailPage = this.byId("sampleDataDetailPage");
				var oContext = oEvent.getSource().getSelectedItem().getBindingContext();
				oDetailPage.setBindingContext(oContext);

				this._createFnImportDetailPage();
			},

			/**
			 * Creates the Detail Page of a Function Import
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_createFnImportDetailPage: function() {
				var oDetailPage = this.byId("sampleDataDetailPage");
				this.byId("sampleDataDetailContent").destroyContent();
				var oController = this;

				var sContextPath = oDetailPage.getBindingContext().getPath();
				var oModel = this.getView().getModel();

				var sTitle = oDetailPage.getBindingContext().getProperty("name");
				oDetailPage.setTitle(sTitle);

				var sEntitySet = oDetailPage.getBindingContext().getProperty("entitySet");
				var sHTTPMethod = oDetailPage.getBindingContext().getProperty("httpMethod");

				var oPanel = new sap.m.Panel(this.createId("FnImportPanel"), {
					expandable: true,
					expanded: true,
					width: "auto",
					headerToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Text({
								text: "Function Import"
							}),

							new sap.m.ToolbarSpacer(),

							new sap.m.Button({
								icon: "sap-icon://add",
								press: $.proxy(this._addFnImportRequestData, this)
							}).addStyleClass("oDataTrackerButton")
						]
					}),
					infoToolbar: new sap.m.Toolbar({
						content: [
							new sap.m.Text({
								text: "Entity Set: " + sEntitySet
							}),

							new sap.m.ToolbarSpacer(),

							new sap.m.Text({
								text: "HTTP Method: " + sHTTPMethod
							})
						]
					})
				});
				this.byId("sampleDataDetailContent").addContent(oPanel);
				oPanel.bindAggregation("content", {
					path: sContextPath + "/RequestData/",
					factory: function(sId, oContext) {
						return oController._addContentsToFnImportDetailPagePanel(oContext.getPath());
					}
				});
			},

			/**
			 * Adds content to the Detail Page of a Function Import
			 * 
			 * @param: {string} sCurrentPath context path
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_addContentsToFnImportDetailPagePanel: function(sCurrentPath) {
				var oModel = this.getView().getModel();

				// TODO : Think of better solution
				var aPaths = sCurrentPath.split("/");
				var iIndex = parseInt(aPaths[aPaths.length - 1], 10);

				var oEntity = oModel.getProperty(sCurrentPath);
				var aParameters = oEntity.parameter;
				var sContextPath = this.byId("sampleDataDetailPage").getBindingContext().getPath();

				var oForm = new sap.ui.layout.form.SimpleForm({
					layout: "ResponsiveGridLayout",
					editable: true
				}).addStyleClass("oDataTrackerSampleDataForm");

				var oHeader = new sap.m.Toolbar({
					content: [
						new sap.m.Title({
							text: "Sample Data - " + (iIndex + 1)
						}).addStyleClass("oDataTrackerSampleDataFormTitle"), new sap.m.ToolbarSpacer(), new sap.m.Button({
							customData: [
								{
									Type: "sap.ui.core.CustomData",
								}
							],
							icon: "sap-icon://sys-cancel-2",
							press: $.proxy(this.handleDeleteFnImportSampleData, this)
						}).addStyleClass("oDataIconButton")
					]
				});

				// Error Message to be displayed if data is entered and all fields aren't filled
				var oErrorMsg = new sap.m.MessageStrip({
					text: "{i18n>Sample_Data_Config_Function_Imports_Error_Message}",
					type: sap.ui.core.MessageType.Error,
					visible: {
						path: sCurrentPath + "/Valid",
						formatter: function(bValid) {
							if (!bValid) {
								return true;
							} else {
								return false;
							}
						}
					}
				});

				// Error Message to be displayed if there are no parameters in the Function Import
				var oNoDataErrorMsg = new sap.m.MessageStrip({
					text: "{i18n>Sample_Data_Config_No_Function_Imports}"
				});

				var oVerticalLayout = new sap.ui.layout.VerticalLayout({});
				oVerticalLayout.addContent(oErrorMsg);
				oVerticalLayout.addContent(oHeader);

				oForm.addContent(oVerticalLayout);

				if (!aParameters.length) {
					oForm.addContent(oNoDataErrorMsg);
					oForm.removeContent(oVerticalLayout);
				}

				for (var i = 0; i < aParameters.length; i++) {

					var iLength = aParameters[i].maxLength ? parseInt(aParameters[i].maxLength, 10) : 0;

					if (isNaN(iLength)) {
						iLength = 0;
					}

					var sText = "";
					var oLabel = new sap.m.Label({});

					sText = aParameters[i].name;
					oLabel.setText(sText);
					oLabel.setTooltip(sText);
					oLabel.addStyleClass("oDataTrackerKeyProperty sapMLabelRequired");

					var oInput = null;
					var sValuePath = sCurrentPath + "/parameter/" + i + "/value";
					var sValueStatePath = sCurrentPath + "/parameter/" + i + "/ValueState";
					var oProperties = {};

					var fnValueEventHandler = function(oEvent) {
						var oSource = oEvent.getSource();
						var oContext = oSource.getBindingContext();
						var oModel = oContext.getModel();
						var sPath = oContext.getPath();
						var iErrorCount = 0;

						var bDataEntered = false;
						for (var j = 0; j < aParameters.length; j++) {
							if (aParameters[j].value) {
								bDataEntered = true;
							}
						}

						for (var j = 0; j < aParameters.length; j++) {
							if ((aParameters[j].value) || (!bDataEntered)) {
								oModel.setProperty(sPath + "/parameter/" + j + "/ValueState", "None");
							} else if ((!aParameters[j].value) && (bDataEntered)) {
								aParameters[j].ValueState = "Error";
								oModel.setProperty(sPath + "/parameter/" + j + "/ValueState", "Error");
								iErrorCount++;
							}
						}

						var iIndex = sPath.split("RequestData/")[1];
						if (iErrorCount === 0) {
							oModel.setProperty(sPath + "/Valid", true);
						} else {
							oModel.setProperty(sPath + "/Valid", false);
						}

						if (bDataEntered) {
							oModel.setProperty(sPath + "/DataEntered", true);
						} else {
							oModel.setProperty(sPath + "/DataEntered", false);
						}
					};

					oInput = this._createControlForODataType(aParameters[i].type, sValuePath, oProperties, {}, sValueStatePath, fnValueEventHandler);

					oForm.addContent(oLabel);
					oForm.addContent(oInput);
				}
				return oForm;
			},

			/**
			 * Adds Request Data to a Function Import
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			_addFnImportRequestData: function(oEvent) {
				var oModel = this.getView().getModel();
				var oDetailPage = this.byId("sampleDataDetailPage");
				var sContextPath = oDetailPage.getBindingContext().getPath();

				var oFnImportCopy = $.extend(true, {}, oModel.getProperty(sContextPath));

				// Get Function Import
				var aFnImports = [];
				var iIndex = 0;
				var sCurrentPath = "";

				this._panelResizeHelper(oEvent.getSource());

				aFnImports = oModel.getProperty(sContextPath + "/RequestData");
				aFnImports.push(oFnImportCopy);
				iIndex = aFnImports.length - 1;
				sCurrentPath = sContextPath + "/RequestData/" + iIndex;
				oModel.setProperty(sContextPath + "/RequestData", aFnImports);
			},

			/**
			 * Deletes Sample Data from a Function Import
			 * 
			 * @param: {sap.ui.base.Event} oEvent the routing event
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.SampleDataConfig
			 */
			handleDeleteFnImportSampleData: function(oEvent) {
				var oModel = this.getView().getModel();
				var oDeleteButton = oEvent.getSource();
				var oContext = oDeleteButton.getBindingContext();

				var oDetailPage = this.byId("sampleDataDetailPage");
				var sDetailPageContextPath = oDetailPage.getBindingContext().getPath();

				var aReqDatas = oModel.getProperty(sDetailPageContextPath + "/RequestData");

				if (!aReqDatas || aReqDatas.length <= 1) {
					return;
				}

				this._panelResizeHelper(oDeleteButton);
				var iIndex = aReqDatas.indexOf(oModel.getProperty(oContext.getPath()));
				if (iIndex !== -1) {
					aReqDatas.splice(iIndex, 1);
				}
				oModel.setProperty(sDetailPageContextPath + "/RequestData", aReqDatas);
			},

			/**
			 * TODO : Document
			 */
			_fnGivePanelRef: function(oControl) {
				if (oControl instanceof sap.m.Panel) {
					return oControl;
				} else {
					return oControl.getParent() ? this._fnGivePanelRef(oControl.getParent()) : null;
				}
			},
		});
	});
})();