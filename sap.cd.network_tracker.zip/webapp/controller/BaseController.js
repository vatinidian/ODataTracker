(function() {
    "use strict";
    sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/routing/History"], function(Controller, History) {
        return Controller.extend("sap.cd.ODataTracker.controller.BaseController", {

            /**
             * Returns Router Instance, all controller which inherits this controller can access this router method
             * 
             */
            getRouter : function() {
                return sap.ui.core.UIComponent.getRouterFor(this);
            },

            /**
             * Returns the component for the controller.
             * 
             */
            getComponent : function() {
                var sOwner = sap.ui.core.Component.getOwnerIdFor(this.getView());
                var oComponent = sap.ui.component(sOwner);

                // Overwrite getter to accelerate future access.
                this.getComponent = function() {
                    return oComponent;
                };

                return oComponent;
            },

            /**
             * TODO : Check whether this can be moved to Custom Router(yet to develop)
             * 
             */
            navBack : function(oEvent) {
                var oHistory, sPreviousHash;
                oHistory = History.getInstance();
                sPreviousHash = oHistory.getPreviousHash();
                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    // TODO : Change Route Name
                    this.getRouter().navTo("appHome", {}, true /* no history */);
                }
            },
            
            /**
             * 
             */
            getI18nText : function(sTextKey, aParameters) {
                return sap.ui.getCore().getRootComponent().getModel("i18n").getResourceBundle().getText(sTextKey, aParameters);
            }
        });
    });
})();