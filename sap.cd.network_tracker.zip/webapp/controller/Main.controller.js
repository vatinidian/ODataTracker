(function() {
	"use strict";
	sap.ui.define([
		"sap/cd/ODataTracker/controller/BaseController", "sap/ui/model/json/JSONModel"
	], function(BaseController, JSONModel) {
		return BaseController.extend("sap.cd.ODataTracker.controller.Main", {
			/**
			 * 
			 * 
			 */
			onInit: function() {
				/**/
				this._oUploadConfigDialog = null;
				this._oUpdateMetadataPopover = null;
				this._sUploadContent = "";
				this._bDynamicSideContent = false;
				this._oTree = null;
				/**/
				this.getView().byId("DynamicSideContent").setShowSideContent(false);

				this.getView().addCustomData(new sap.ui.core.CustomData({
					key: "ViewName",
					value: "MainView"
				}));

				var oContainer = this.byId("navigationContainer");
				this.getComponent().getNavigationHelper().createNavigationTabs(oContainer);

				// TODO : Check for better solution
				sap.ui.Device.resize.attachHandler(function() {
					this.getView().byId("DynamicSideContent").setShowSideContent(this._bDynamicSideContent);
				}, this);

				this.getComponent().getModelHelper().registerForSchemaChange(function(bSchemaChanged) {
					if (bSchemaChanged) {
						this.loadTree();
					}
				}, this);
			},

			/**
			 * 
			 */
			_createDragAndDropEventListener: function() {

				var oFileDropBox = sap.ui.core.Fragment.byId("uploadConfig", "fileDropBox").$()[0];
				var oController = this;

				oFileDropBox.addEventListener("dragover", function(oEvent) {
					oEvent.preventDefault();
				});
				oFileDropBox.addEventListener("drop", function(oEvent) {

					var oFile = oEvent.dataTransfer.files[0];
					if (!oFile || oFile.type !== "text/plain" && oFile.type !== "text/xml") { // Show Toast
						oController._sUploadContent = "";
						return;
					}

					var oReader = new FileReader();

					oReader.addEventListener("load", function(oEvent2) {

						var sFileContent = oReader.result;
						oController._sUploadContent = sFileContent;

						var oDropBox = sap.ui.core.Fragment.byId("uploadConfig", "fileDropBox");
						oDropBox.removeAllContent();

						oDropBox.addContent(new sap.m.Image({
							src: "image/file.png"
						}).addStyleClass("sapUiSmallMarginTop oDataTrackUploadImage"));

						oDropBox.addContent(new sap.m.Text({
							text: oFile.name + " - uploaded !"
						}).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginEnd"));

					});
					oReader.readAsText(oFile);

					oEvent.preventDefault();
				});

			},

			/**
			 * 
			 */
			_parseConfigurationFile: function() {
				if (!this._sUploadContent) {
					return;
				}

				this.getComponent().getNavigationHelper().resetNavTabsToInitialState();

				var oContent = "";
				try {
					oContent = JSON.parse(this._sUploadContent);
				} catch (ex) {
					this._sUploadContent = "";
					$.sap.log.error("Error While parsing uploaded file", "Main.View", "ODataTracker");
				}

				// Change the Project title state
				var oButton = this.byId("projectTitleEditIcon");
				var oInput = this.byId("projectTitleInput");
				oButton.setIcon("sap-icon://edit");
				oButton.setTooltip("Edit Project title");
				oInput.setEditable(false);
				oInput.addStyleClass("oDataAppTitleProjectDisplayMode");

				var oModel = this.getView().getModel();
				oContent.ModelLoadedFromFile = true;
				oContent.ConfigurationFileused = true;
				oModel.setProperty("/", oContent);

				// Get the current Screen and Route
				var sScreenTarget = oContent.CurrentScreen.RouteName;
				this.getRouter().getTargets().display(sScreenTarget);

				// Select the NavTab
				this.getComponent().getNavigationHelper().goToNavTab(oContent.CurrentScreen.RouteName);

				this._sUploadContent = "";
			},

			/**
			 * 
			 */
			handleProjectTitleButtonPress: function(oEvent) {
				var oButton = oEvent.getSource();
				var oInput = this.byId("projectTitleInput");
				if (!oInput.getValue().trim()) {
					sap.m.MessageToast.show("Enter Project Name");
					oButton.setPressed(!oButton.getPressed());
					return;
				}

				if (oButton.getPressed()) {
					oButton.setIcon("sap-icon://edit");
					oButton.setTooltip("Edit Project title");
					oInput.setEditable(false);
					oInput.addStyleClass("oDataAppTitleProjectDisplayMode");
				} else {
					oButton.setIcon("sap-icon://display");
					oButton.setTooltip("Display Project title");
					oInput.setEditable(true);
					oInput.removeStyleClass("oDataAppTitleProjectDisplayMode");
				}
			},

			/**
			 * 
			 */
			handleProjectTitleChange: function(oEvent) {
				var oInput = oEvent.getSource();
				var oButton = this.byId("projectTitleEditIcon");

				if (!oInput.getValue().trim()) {
					sap.m.MessageToast.show("Enter Project Name");
					oButton.setPressed(!oButton.getPressed());
					return;
				}

				oButton.setPressed(!oButton.getPressed());
				oButton.firePress();
				oInput.setEditable(false);
				oInput.addStyleClass("oDataAppTitleProjectDisplayMode");
			},

			/**
			 * 
			 */
			handleUploadConfigDialogOpen: function() {

				if (!this._oUploadConfigDialog) {
					this._oUploadConfigDialog = sap.ui.xmlfragment("uploadConfig", "sap.cd.ODataTracker.view.fragment.UploadConfigFile",
						this);

					var oController = this;
					var oFileUploader = sap.ui.core.Fragment.byId("uploadConfig", "fileUploader");

					oFileUploader.attachBrowserEvent("change", function(oEvent) {
						if (!!(window.File) && !!(window.FileReader) && !!(window.FileList) && !!(window.Blob)) {

							var oFile = oEvent.target.files[0];

							if (!oFile || oFile.type !== "text/plain" && oFile.type !== "text/xml") {
								// Show Toast
								oController._sUploadContent = "";
								return;
							}
							var oReader = new FileReader();
							oReader.onload = function(e) {
								var sFileContent = oReader.result;
								oController._sUploadContent = sFileContent;
							};
							oReader.readAsText(oFile);

						} else {
							// Show toast
							// File API is not supported by your browser!;
						}
					});

					var oFileDropBox = sap.ui.core.Fragment.byId("uploadConfig", "fileDropBox");
					oFileDropBox.addEventDelegate({
						onAfterRendering: function() {
							this._createDragAndDropEventListener();
						}
					}, this);

				}

				var oFileDropBox = sap.ui.core.Fragment.byId("uploadConfig", "fileDropBox");
				oFileDropBox.removeAllContent();

				oFileDropBox.addContent(new sap.m.Text({
					text: "Drag And Drop Your file here"
				}).addStyleClass("sapUiSmallMargin oDataTrackUploadText"));

				oFileDropBox.addContent(new sap.m.Image({
					src: "image/upload.png"
				}).addStyleClass("oDataTrackUploadImage"));

				var oFileUploader = sap.ui.core.Fragment.byId("uploadConfig", "fileUploader");
				if (oFileUploader.getValue()) {
					// oFileUploader.clear();
				}

				var oModel = this.getView().getModel();
				oModel.setProperty("/ModelLoadedFromFile", false);

				this._oUploadConfigDialog.open();
			},

			handleUploadDialogClose: function() {
				this._sUploadContent = "";
				this._oUploadConfigDialog.close();
			},

			handleUploadConfigFile: function() {
				this._parseConfigurationFile();
				this._oUploadConfigDialog.close();
			},

			handleDownloadPress: function() {
				var sContent = this._createDownloadContent();
				var oCurrentBrowser = sap.ui.Device.browser;
				// Current working Browser Name
				var sCurrentBrowserName = oCurrentBrowser.name;

				// TODO: Check the browser (for IE , behave diff)
				// Microsoft Internet Explorer
				if (sCurrentBrowserName !== "ie") {
					var sFileName = this.byId("projectTitleInput").getValue().trim() ? (this.byId("projectTitleInput").getValue() +
						" - Configuration (" + new Date().toLocaleString() + ")") : "NetWork Configuration (" + new Date().toLocaleString() + ")";

					var pom = document.createElement('a');
					pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(sContent));
					pom.setAttribute('download', sFileName);

					if (document.createEvent) {
						var oEvent = document.createEvent('MouseEvents');
						oEvent.initEvent('click', true, true);
						pom.dispatchEvent(oEvent);
					} else {
						pom.click();
					}
				} else {
					var sURIContent = "data:application/octet-stream," + encodeURIComponent(sContent);
					window.open(sURIContent);
				}
			},

			_createDownloadContent: function() {
				var oModelData = this.getView().getModel().getData();
				var sContent = JSON.stringify(oModelData);
				return sContent;
			},

			onAfterRendering: function() {
				this.getView().byId("DynamicSideContent").setShowSideContent(false);

				var sMessageStripID = this.createId("mainMsgStrip");
				var sMainPageID = this.createId("mainPage");
				$("#" + sMessageStripID).draggable({
					containment: "#" + sMainPageID,
					scroll: false
				});
			},

			handleSideContentHide: function(oEvent) {
				this.getView().byId("DynamicSideContent").setShowSideContent(false);
				this._bDynamicSideContent = false;
			},

			handleSideContentShow: function(oEvent) {
				this.getView().byId("DynamicSideContent").setShowSideContent(true);
				this._bDynamicSideContent = true;

				this.loadTree();
			},

			/**
			 * Handles the Press Event of the Refresh Button in the Dynamic Side Content
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.Main
			 */
			handleRefreshTree: function() {
				this.loadTree();

				// If there is a Query in the Search Field, don't collapse the Tree
				if (this.byId("treeSearch").getValue() !== "") {
					this._oTree.expandAll();
				}
			},

			handleExpandTree: function() {
				this._oTree.expandAll();
			},

			handleCollapseTree: function() {
				this._oTree.collapseAll();
			},

			/**
			 * Loads the Tree in case there is none else refreshes the Model
			 * 
			 * @memberOf: sap.cd.ODataTracker.ODataTracker.Main
			 */
			loadTree: function() {
				var oModel = this.getView().getModel();
				var oSchema = oModel.oData.schema;

				var oModelHelper = this.getComponent().getModelHelper();
				var oTreeData = oModelHelper.getTreeModel("schema", oSchema);

				var oTreeModel = this.getComponent().getModel("treeModel");
				oTreeModel.setData(oTreeData);

				// Create the Tree if it doesn't exist
				if (!this._oTree) {
					// Add Tree only if schema is available
					if (oSchema) {
						this.byId("treeToolbar").setVisible(true);
						var oNodeTemplate = new sap.ui.commons.TreeNode({
							text: {
								parts: [{
									path: "treeModel>text"
								}],
								formatter: function(sText) {
									return sText;
								}
							}
						});

						this._oTree = new sap.ui.commons.Tree({
							showHeader: false,
							width: "100%",
							height: "auto"
						}).bindNodes({
							path: "treeModel>/",
							template: oNodeTemplate,
							parameters: {
								arrayNames: [
									"nodes"
								]
							}
						});

						this.byId("DynamicSideContent").addSideContent(this._oTree);
					}
				}
				this._oTree.collapseAll();
			},

			handleTreeSearch: function(oEvent) {
				var sQuery = oEvent ? oEvent.getParameter("query").toLowerCase() : "";
				var oFilter = null;

				if (sQuery) {
					// Filter for Tree Nodes
					oFilter = new sap.ui.model.Filter([
						new sap.ui.model.Filter("filterProperty", sap.ui.model.FilterOperator.Contains, sQuery)
					], false);
				}

				this._oTree.getBinding("nodes").filter(oFilter, "Application");
				this._oTree.expandAll();

				if (!sQuery) {
					// Collapse the Tree if Search Field is cleared
					this._oTree.collapseAll();
				}
			},

			handleMetdataUpdate: function(oEvent) {
				if (!this._oUpdateMetadataPopover) {
					this._oUpdateMetadataPopover = sap.ui.xmlfragment("updateMetadata", "sap.cd.ODataTracker.view.fragment.UpdateMetadata",
						this);
					this.getView().addDependent(this._oUpdateMetadataPopover);
				}
				this._oUpdateMetadataPopover.openBy(oEvent.getSource());
			},

			handleUpdateButtonPress: function() {
				var sValue = this.getView().getModel().getProperty("/ServiceUrl");
				this.getComponent().getModelHelper().compareMainModel(sValue);

				this._oUpdateMetadataPopover.close();
			},

			handleCloseButton: function() {
				this._oUpdateMetadataPopover.close();
			}
		});
	});
})();